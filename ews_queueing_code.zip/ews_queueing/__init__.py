"""EWS analysis for tandem loss / infinite-server network."""
