"""
GPU-accelerated simulation of the tandem M/M/n/n → M/M/∞ network
with state-dependent Hill-function routing.

Station 1: M/M/n/n loss system (Erlang-B), HW regime λ = n - θ√n, μ₁ = 1
Station 2: M/M/∞ infinite-server queue, service rate γ per server
Routing:   p̃(Q₂) = ε + (1-ε) · Q₂²/(Q₂² + K²),  K = α·Λ/γ

Uses tau-leaping for efficient GPU vectorisation across B replicas.
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, Callable

try:
    import cupy as cp
    GPU_AVAILABLE = True
    print("[tandem_sim] CuPy detected — using GPU")
except ImportError:
    import numpy as cp  # fallback
    GPU_AVAILABLE = False
    print("[tandem_sim] CuPy not found — falling back to NumPy (CPU)")


@dataclass
class NetworkParams:
    """Parameters for the tandem network."""
    n: int = 1000              # number of servers at station 1
    theta: float = 0.5         # HW parameter: λ = n - θ√n
    gamma: float = 1.0         # service rate at station 2
    alpha: float = 0.3         # Hill function half-saturation: K = α · n₂ʰⁱ
    epsilon: float = 0.01      # baseline routing probability
    mu1: float = 1.0           # service rate at station 1

    @property
    def lam(self) -> float:
        """Arrival rate to station 1."""
        return self.n - self.theta * np.sqrt(self.n)

    @property
    def Lambda(self) -> float:
        """Fluid-level throughput of station 1."""
        return min(self.lam, self.n)

    @property
    def n2_hi(self) -> float:
        """Natural scale of station 2: Λ/γ."""
        return self.Lambda / self.gamma

    @property
    def K(self) -> float:
        """Hill function half-saturation point."""
        return self.alpha * self.n2_hi

    @property
    def delta(self) -> float:
        """Bifurcation parameter: δ = 1/4 - α²."""
        return 0.25 - self.alpha ** 2

    def fixed_points(self) -> dict:
        """Compute fluid fixed points of station 2 (normalised by n₂ʰⁱ)."""
        disc = 1 - 4 * self.alpha ** 2
        if disc < 0:
            return {"exists": False, "q_plus": 0.5, "q_minus": 0.5}
        sq = np.sqrt(disc)
        return {
            "exists": disc > 0,
            "q_plus": (1 + sq) / 2,   # stable upper
            "q_minus": (1 - sq) / 2,  # unstable threshold
        }


def hill_routing(Q2, K, epsilon=0.01):
    """Hill-function routing probability (vectorised, works on GPU arrays)."""
    q2sq = Q2 * Q2
    return epsilon + (1.0 - epsilon) * q2sq / (q2sq + K * K + 1e-30)


class TandemSimulator:
    """
    Vectorised tau-leaping simulator for B independent replicas
    of the tandem loss/∞-server network.
    """

    def __init__(self, params: NetworkParams, B: int = 4096,
                 dt_sim: float = 0.005, seed: int = 42):
        """
        Args:
            params: network parameters
            B: number of parallel replicas
            dt_sim: tau-leaping time step
            seed: RNG seed
        """
        self.p = params
        self.B = B
        self.dt = dt_sim

        if GPU_AVAILABLE:
            self.rng = cp.random.RandomState(seed)
        else:
            self.rng = np.random.RandomState(seed)

    def _step(self, Q1, Q2, alpha_t, n_t=None):
        """
        One tau-leaping step for all B replicas.

        Args:
            Q1: (B,) int array — station 1 occupancy
            Q2: (B,) int array — station 2 occupancy
            alpha_t: current alpha value (scalar)
            n_t: current station-1 capacity (int), or None to use self.p.n

        Returns:
            Q1_new, Q2_new
        """
        xp = cp  # cupy or numpy
        dt = self.dt
        p = self.p

        n_now = int(n_t) if n_t is not None else p.n
        lam = n_now - p.theta * np.sqrt(n_now)
        n2hi = lam / p.gamma  # fluid scale
        K = alpha_t * n2hi

        # --- Rates ---
        # Arrivals to station 1 (blocked if Q1 >= n_now)
        arr_rate = lam * (Q1 < n_now).astype(cp.float64)

        # Departures from station 1
        dep1_rate = Q1.astype(cp.float64) * p.mu1

        # Routing probability
        p_route = hill_routing(Q2.astype(cp.float64), K, p.epsilon)

        # Departures from station 2
        dep2_rate = Q2.astype(cp.float64) * p.gamma

        # --- Tau-leaping: sample Poisson event counts ---
        n_arr1 = self.rng.poisson(xp.maximum(arr_rate * dt, 0.0)).astype(cp.int64)
        n_dep1 = self.rng.poisson(xp.maximum(dep1_rate * dt, 0.0)).astype(cp.int64)
        n_dep2 = self.rng.poisson(xp.maximum(dep2_rate * dt, 0.0)).astype(cp.int64)

        # Departures from station 1: each is routed to station 2 with prob p_route
        n_dep1_clipped = xp.minimum(n_dep1, Q1)  # can't depart more than present
        n_route = self.rng.poisson(
            xp.maximum(n_dep1_clipped.astype(cp.float64) * p_route, 0.0)
        ).astype(cp.int64)
        n_route = xp.minimum(n_route, n_dep1_clipped)

        # --- Update states ---
        Q1_new = xp.clip(Q1 + n_arr1 - n_dep1_clipped, 0, n_now)
        Q2_new = xp.maximum(Q2 + n_route - n_dep2, 0)

        return Q1_new.astype(cp.int64), Q2_new.astype(cp.int64)

    def simulate(self, T: float, dt_record: float = 1.0,
                 Q1_init=None, Q2_init=None,
                 alpha_schedule: Optional[Callable] = None,
                 n_schedule: Optional[Callable] = None,
                 burnin_frac: float = 0.0):
        """
        Run simulation for time T, recording every dt_record.

        Args:
            T: total simulation time
            dt_record: recording interval
            Q1_init: initial Q1 per replica (scalar or (B,) array)
            Q2_init: initial Q2 per replica (scalar or (B,) array)
            alpha_schedule: callable alpha(t) -> float, or None for constant alpha
            n_schedule: callable n(t) -> int, or None for constant n.
                        When provided, station 1 capacity grows over time.
                        alpha_schedule is computed from n_schedule if both
                        are None-for-alpha but n_schedule is given.
            burnin_frac: fraction of T to discard as burn-in

        Returns:
            dict with keys:
                times: (n_rec,) recording times
                Q1: (n_rec, B) station 1 occupancy
                Q2: (n_rec, B) station 2 occupancy
                alpha_t: (n_rec,) alpha at each recording time
                n_t: (n_rec,) station 1 capacity at each recording time
        """
        xp = cp
        B = self.B
        p = self.p
        dt = self.dt

        n_0 = p.n

        # Initialise
        if Q1_init is None:
            Q1 = xp.full(B, n_0, dtype=cp.int64)
        elif np.isscalar(Q1_init):
            Q1 = xp.full(B, int(Q1_init), dtype=cp.int64)
        else:
            Q1 = xp.asarray(Q1_init, dtype=cp.int64)

        if Q2_init is None:
            Q2 = xp.zeros(B, dtype=cp.int64)
        elif np.isscalar(Q2_init):
            Q2 = xp.full(B, int(Q2_init), dtype=cp.int64)
        else:
            Q2 = xp.asarray(Q2_init, dtype=cp.int64)

        n_steps = int(T / dt)
        rec_every = max(1, int(dt_record / dt))
        n_rec = n_steps // rec_every + 1

        # Storage (on GPU)
        Q1_hist = xp.zeros((n_rec, B), dtype=cp.int64)
        Q2_hist = xp.zeros((n_rec, B), dtype=cp.int64)
        times = np.zeros(n_rec)
        alpha_vals = np.zeros(n_rec)
        n_vals = np.zeros(n_rec, dtype=np.int64)

        rec_idx = 0
        for step in range(n_steps):
            t = step * dt

            # Current n (constellation size)
            if n_schedule is not None:
                n_t = int(n_schedule(t))
            else:
                n_t = n_0

            # Current alpha
            if alpha_schedule is not None:
                alpha_t = alpha_schedule(t)
            else:
                alpha_t = p.alpha

            # Record
            if step % rec_every == 0 and rec_idx < n_rec:
                Q1_hist[rec_idx] = Q1
                Q2_hist[rec_idx] = Q2
                times[rec_idx] = t
                alpha_vals[rec_idx] = alpha_t
                n_vals[rec_idx] = n_t
                rec_idx += 1

            # Advance
            Q1, Q2 = self._step(Q1, Q2, alpha_t, n_t=n_t)

        # Final record
        if rec_idx < n_rec:
            Q1_hist[rec_idx] = Q1
            Q2_hist[rec_idx] = Q2
            times[rec_idx] = step * dt
            alpha_vals[rec_idx] = alpha_t if alpha_schedule else p.alpha
            n_vals[rec_idx] = n_t if n_schedule else n_0
            rec_idx += 1

        # Trim
        Q1_hist = Q1_hist[:rec_idx]
        Q2_hist = Q2_hist[:rec_idx]
        times = times[:rec_idx]
        alpha_vals = alpha_vals[:rec_idx]
        n_vals = n_vals[:rec_idx]

        # Apply burn-in
        burnin_idx = int(burnin_frac * rec_idx)

        # Transfer to CPU
        return {
            "times": times[burnin_idx:],
            "Q1": xp.asnumpy(Q1_hist[burnin_idx:]) if GPU_AVAILABLE else Q1_hist[burnin_idx:],
            "Q2": xp.asnumpy(Q2_hist[burnin_idx:]) if GPU_AVAILABLE else Q2_hist[burnin_idx:],
            "alpha_t": alpha_vals[burnin_idx:],
            "n_t": n_vals[burnin_idx:],
        }


def make_alpha_ramp(alpha_0, alpha_c, t0, tau_r):
    """
    Create a linear ramping schedule for alpha:
        alpha(t) = alpha_0                           for t < t0
        alpha(t) = alpha_0 + (alpha_c - alpha_0) * (t - t0) / tau_r   for t >= t0

    Args:
        alpha_0: initial alpha (e.g. 0.3)
        alpha_c: critical alpha (0.5)
        t0: time ramping begins
        tau_r: ramping duration (tipping at t0 + tau_r)
    """
    def schedule(t):
        if t < t0:
            return alpha_0
        else:
            return min(alpha_c, alpha_0 + (alpha_c - alpha_0) * (t - t0) / tau_r)
    return schedule


def make_physical_alpha_schedule(gamma, V, sigma_dd, v_rel, lam_0, r):
    """
    Physical α(t) = C / λ(t) derived from debris collision kinetics.

    The half-saturation K = γV / (σ_dd · v_rel) is a physical constant
    determined by orbital geometry and collision physics. Since
    α = K / n₂ʰⁱ = Kγ / Λ = C / λ, we get α(t) = C / (λ₀ + r·t).

    The saddle-node bifurcation occurs when α = 0.5, i.e., at:
        λ_crit = 2C,    t_bif = (λ_crit - λ₀) / r

    Args:
        gamma:    service rate at station 2 (debris removal / drag rate)
        V:        effective orbital shell volume
        sigma_dd: debris-debris collision cross-section
        v_rel:    mean relative velocity of debris
        lam_0:    initial launch rate
        r:        launch rate growth (linear: λ(t) = λ₀ + r·t)

    Returns:
        schedule: callable alpha(t) -> float
        info:     dict with C, K, lambda_crit, t_bif
    """
    C = gamma ** 2 * V / (sigma_dd * v_rel)
    K = gamma * V / (sigma_dd * v_rel)
    lam_crit = 2 * C
    t_bif = (lam_crit - lam_0) / r if r > 0 else np.inf

    def schedule(t):
        lam_t = lam_0 + r * t
        return C / max(lam_t, 1e-10)

    info = {
        "C": C,
        "K_physical": K,
        "lambda_crit": lam_crit,
        "t_bif": t_bif,
        "alpha_0": C / lam_0,
    }
    return schedule, info


def calibrate_physical_params(n, alpha_0, gamma=1.0):
    """
    Given a desired initial α₀ and system size n, back out the
    physical constants (C, λ₀) and a reasonable growth rate r.

    This lets us set up a physically-grounded simulation where α starts
    above 0.5 (safe) or at any desired value, and drifts due to
    growing launch rate.

    Args:
        n:        station 1 capacity (sets the scale)
        alpha_0:  desired initial α value
        gamma:    station 2 service rate

    Returns:
        dict with lam_0, C, and suggested r for various timescales
    """
    theta = 0.5
    lam_0 = n - theta * np.sqrt(n)  # HW arrival rate
    C = alpha_0 * lam_0             # from α₀ = C/λ₀
    lam_crit = 2 * C                # bifurcation at α = 0.5

    return {
        "lam_0": lam_0,
        "C": C,
        "lambda_crit": lam_crit,
        "alpha_0": alpha_0,
        # Growth rate to reach bifurcation at time T_bif:
        "r_for_Tbif": lambda T_bif: (lam_crit - lam_0) / T_bif,
    }


def make_split_init(B, Q2_low, Q2_high):
    """Create initial conditions: half low, half high."""
    Q2_init = np.zeros(B, dtype=np.int64)
    Q2_init[:B // 2] = Q2_low
    Q2_init[B // 2:] = Q2_high
    return Q2_init


# ── Quick self-test ──
if __name__ == "__main__":
    params = NetworkParams(n=100, theta=0.5, gamma=1.0, alpha=0.3, epsilon=0.01)
    print(f"Network: n={params.n}, λ={params.lam:.1f}, n₂ʰⁱ={params.n2_hi:.1f}, "
          f"K={params.K:.1f}, δ={params.delta:.4f}")
    fp = params.fixed_points()
    print(f"Fixed points: q₊*={fp['q_plus']:.3f}, q₋*={fp['q_minus']:.3f}")

    sim = TandemSimulator(params, B=64, dt_sim=0.005, seed=0)
    Q2_init = make_split_init(64, 0, int(params.n2_hi))
    result = sim.simulate(T=50, dt_record=0.5, Q2_init=Q2_init)
    print(f"Simulated: {result['times'].shape[0]} time points, "
          f"Q2 range [{result['Q2'].min()}, {result['Q2'].max()}]")
