"""
real_data_pipeline.py — EWS analysis on observed orbital debris data.

This is the single-timeseries analog of the Ditlevsen & Ditlevsen AMOC
analysis, applied to the Kessler syndrome problem.

Data sources:
  - Space-Track.org SATCAT (satellites + debris catalog)
  - ESA DISCOS / Space Debris User Portal
  - Jonathan McDowell's General Catalog (planet4589.org)
  - Or any CSV with columns: year, active_satellites, debris_count, launches

Pipeline:
  1. Load and filter by orbital shell (altitude band)
  2. Construct time series: Q1(t), Q2(t), λ(t)
  3. Estimate physical parameters: γ (decay rate), ε (baseline collision prob)
  4. Calibrate K_phys from fragmentation event history
  5. Compute α(t) = K_phys·γ/λ(t) and δ(t) = 1/4 - α(t)²
  6. Running-window EWS: variance, autocorrelation, restoring rate
  7. Tipping-time estimation (moment-based + bootstrap)
  8. Diagnostic plots

Usage:
  python real_data_pipeline.py --csv debris_data.csv
  python real_data_pipeline.py --csv debris_data.csv --alt_min 500 --alt_max 600
  python real_data_pipeline.py --demo  # run on synthetic "realistic" data
"""

import numpy as np
import os
import argparse
import warnings
from dataclasses import dataclass, field
from typing import Optional, Tuple, List

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

# Reuse our EWS and estimation modules
from ews_analysis import (
    compute_running_window_ews, se_variance, se_autocorrelation,
    EWSResult,
)
from tipping_estimator import estimate_tipping_moment, TippingEstimate


# ── Plot styling ──
plt.rcParams.update({
    'figure.facecolor': '#0f172a',
    'axes.facecolor': '#1e293b',
    'text.color': '#e2e8f0',
    'axes.labelcolor': '#cbd5e1',
    'xtick.color': '#94a3b8',
    'ytick.color': '#94a3b8',
    'axes.edgecolor': '#334155',
    'grid.color': '#334155',
    'grid.alpha': 0.5,
    'font.family': 'sans-serif',
    'font.size': 11,
    'axes.titlesize': 13,
    'axes.titleweight': 'bold',
})
COLORS = {
    'blue': '#38bdf8', 'purple': '#a78bfa', 'orange': '#fb923c',
    'green': '#34d399', 'red': '#f87171', 'yellow': '#fbbf24',
    'cyan': '#22d3ee', 'pink': '#f472b6', 'gray': '#64748b',
}

OUT_DIR = "results"
os.makedirs(OUT_DIR, exist_ok=True)


# ═══════════════════════════════════════════════════════════════
# 0. Altitude-Dependent Physics
# ═══════════════════════════════════════════════════════════════

# Approximate debris orbital lifetime model from atmospheric density.
# Based on exponential atmosphere with piecewise scale heights
# calibrated to the NRLMSISE-00 model at moderate solar activity (F10.7 ~ 140).
#
# References:
#   - Vallado, "Fundamentals of Astrodynamics and Applications"
#   - King-Hele, "Satellite Orbits in an Atmosphere"

# (altitude_km, scale_height_km, base_density_kg/m3)
_ATMOSPHERE_TABLE = [
    (200,  37.0,  2.5e-10),
    (300,  40.0,  1.8e-11),
    (400,  52.0,  3.7e-12),
    (500,  63.0,  5.2e-13),
    (600,  73.0,  9.5e-14),
    (700,  83.0,  2.2e-14),
    (800,  94.0,  5.8e-15),
    (900, 105.0,  1.7e-15),
    (1000, 116.0, 5.2e-16),
]


def atmospheric_density(h_km: float) -> float:
    """
    Approximate atmospheric density at altitude h (km).

    Uses piecewise exponential interpolation calibrated to NRLMSISE-00
    at moderate solar activity. Accuracy: factor of 2-3 (sufficient
    for order-of-magnitude lifetime estimates).
    """
    table = _ATMOSPHERE_TABLE
    if h_km <= table[0][0]:
        return table[0][2]
    if h_km >= table[-1][0]:
        h0, H0, rho0 = table[-1]
        return rho0 * np.exp(-(h_km - h0) / H0)

    for i in range(len(table) - 1):
        h0, H0, rho0 = table[i]
        h1, H1, rho1 = table[i + 1]
        if h0 <= h_km <= h1:
            # Interpolate scale height
            frac = (h_km - h0) / (h1 - h0)
            H = H0 + frac * (H1 - H0)
            return rho0 * np.exp(-(h_km - h0) / H)

    return table[-1][2]


def debris_lifetime(h_km: float, A_over_m: float = 0.02) -> float:
    """
    Approximate orbital lifetime of a debris fragment at altitude h (km).

    Uses an empirical fit calibrated to NASA Orbital Debris Program Office
    data and ESA MASTER model outputs at moderate solar activity (F10.7 ~ 140).

    The exponential atmosphere means lifetime increases roughly as
    10^(slope * h). We calibrate to known reference points:
      - 300 km: ~0.5 yr (months)
      - 400 km: ~2 yr
      - 550 km: ~20 yr  (Starlink shell, well-established)
      - 800 km: ~200 yr (sun-synchronous, from ESA reports)
      - 1000 km: ~2000 yr

    These are for debris with A/m ≈ 0.02 m²/kg (typical tracked fragment).
    Higher A/m (smaller, flatter debris) decays faster: τ ∝ 1/A_over_m.

    Args:
        h_km: altitude in km
        A_over_m: area-to-mass ratio in m²/kg (default 0.02)

    Returns:
        lifetime in years
    """
    # Empirical fit: log10(τ_years) is piecewise linear in altitude
    # Calibrated to the reference points above at A/m = 0.02
    _LIFETIME_TABLE = [
        (200,   0.05),   # ~2 weeks
        (300,   0.5),    # ~6 months
        (350,   1.0),    # ~1 year
        (400,   2.5),    # ~2-3 years
        (450,   7.0),    # ~7 years
        (500,   15.0),   # ~15 years
        (550,   25.0),   # ~25 years (Starlink shell)
        (600,   50.0),   # ~50 years
        (650,   90.0),   # ~90 years
        (700,   150.0),  # ~150 years
        (750,   200.0),  # ~200 years
        (800,   300.0),  # ~300 years
        (900,   1000.0), # ~1000 years
        (1000,  2500.0), # ~2500 years
        (1200,  10000.0),# ~10k years
    ]

    # Interpolate in log space
    alts = np.array([t[0] for t in _LIFETIME_TABLE])
    taus = np.array([t[1] for t in _LIFETIME_TABLE])
    log_taus = np.log10(taus)

    if h_km <= alts[0]:
        return taus[0] * (0.02 / A_over_m)
    if h_km >= alts[-1]:
        # Extrapolate
        slope = (log_taus[-1] - log_taus[-2]) / (alts[-1] - alts[-2])
        log_tau = log_taus[-1] + slope * (h_km - alts[-1])
        return 10**log_tau * (0.02 / A_over_m)

    log_tau = np.interp(h_km, alts, log_taus)
    return 10**log_tau * (0.02 / A_over_m)


def gamma_from_altitude(h_km: float, A_over_m: float = 0.02) -> float:
    """
    Debris decay rate γ (per year) from altitude.

    γ = 1 / τ  where τ is the debris orbital lifetime.

    Args:
        h_km: altitude in km
        A_over_m: area-to-mass ratio (m²/kg)

    Returns:
        γ in per year
    """
    tau = debris_lifetime(h_km, A_over_m=A_over_m)
    return 1.0 / max(tau, 0.01)


def K_phys_from_altitude(h_km: float, delta_h_km: float = 50.0,
                          K_phys_ref: float = 11400.0,
                          h_ref: float = 550.0) -> float:
    """
    Scale K_phys with altitude via shell volume.

    K_phys² ∝ V² = [4π(R+h)²Δh]²

    The collision cross-sections, relative velocity, and fragment
    multiplicity are approximately altitude-independent in LEO.

    Args:
        h_km: altitude in km
        delta_h_km: shell thickness in km
        K_phys_ref: K_phys at reference altitude
        h_ref: reference altitude in km

    Returns:
        K_phys at the requested altitude
    """
    R = 6371.0  # km
    V_ref = (R + h_ref) ** 2 * delta_h_km
    V_new = (R + h_km) ** 2 * delta_h_km
    return K_phys_ref * (V_new / V_ref)


def critical_constellation_sizes(h_km: float, epsilon: float = 0.01,
                                  K_phys_ref: float = 11400.0,
                                  delta_h_km: float = 50.0) -> dict:
    """
    Compute altitude-dependent critical constellation sizes.

    Returns:
        dict with gamma, K_phys, n_bif, n_capture, lifetime
    """
    gamma = gamma_from_altitude(h_km)
    K_phys = K_phys_from_altitude(h_km, delta_h_km, K_phys_ref)
    tau = debris_lifetime(h_km)

    n_bif = 2 * K_phys * gamma
    n_capture = K_phys * gamma / np.sqrt(epsilon)

    return {
        "altitude_km": h_km,
        "gamma": gamma,
        "K_phys": K_phys,
        "lifetime_years": tau,
        "n_bif": n_bif,
        "n_capture": n_capture,
        "epsilon": epsilon,
    }


def print_altitude_comparison(epsilon: float = 0.01,
                               K_phys_ref: float = 11400.0):
    """Print a comparison table of critical sizes across altitudes."""
    print(f"\n  {'='*72}")
    print(f"  ALTITUDE COMPARISON (ε = {epsilon}, K_phys_ref = {K_phys_ref:.0f})")
    print(f"  {'='*72}")
    print(f"  {'Alt (km)':>10} {'γ (/yr)':>10} {'Lifetime':>12} "
          f"{'K_phys':>8} {'n_bif':>8} {'n_capture':>10}")
    print(f"  {'-'*10} {'-'*10} {'-'*12} {'-'*8} {'-'*8} {'-'*10}")

    for h in [300, 400, 500, 550, 600, 700, 800, 900, 1000, 1200]:
        c = critical_constellation_sizes(h, epsilon, K_phys_ref)
        lt = c['lifetime_years']
        lt_str = (f"{lt:.1f} yr" if lt < 100
                  else f"{lt:.0f} yr" if lt < 10000
                  else f"{lt/1000:.0f} kyr")
        print(f"  {h:>10.0f} {c['gamma']:>10.4f} {lt_str:>12} "
              f"{c['K_phys']:>8.0f} {c['n_bif']:>8.0f} {c['n_capture']:>10.0f}")

    print()


# ═══════════════════════════════════════════════════════════════
# 1. Data Structures
# ═══════════════════════════════════════════════════════════════

@dataclass
class OrbitalShellData:
    """Time series for a single orbital shell."""
    times: np.ndarray            # years (e.g., 1960.0, 1960.08, ...)
    Q1: np.ndarray               # active satellites in shell
    Q2: np.ndarray               # tracked debris fragments in shell
    launches: np.ndarray         # cumulative or rate of launches
    launch_rate: np.ndarray      # λ(t) — launches per unit time
    alt_min: float = 0.0         # altitude band lower bound (km)
    alt_max: float = 2000.0      # altitude band upper bound (km)
    shell_name: str = "LEO"
    dt: float = 1.0              # time step (years)

    # Optional: fragmentation events for K_phys calibration
    frag_times: Optional[np.ndarray] = None       # times of events
    frag_debris_before: Optional[np.ndarray] = None  # Q2 just before event
    frag_debris_produced: Optional[np.ndarray] = None  # fragments created


@dataclass
class PhysicalParams:
    """Estimated physical parameters for the shell."""
    gamma: float           # debris decay rate (per year)
    epsilon: float         # baseline collision probability
    K_phys: float          # Hill function half-saturation (debris count)
    K_phys_ci: Tuple[float, float] = (0.0, 0.0)  # confidence interval
    lambda_crit: float = 0.0  # critical launch rate (α = 0.5)
    method: str = "fit"


@dataclass
class RealDataEWS:
    """Full EWS analysis result for real data."""
    shell: OrbitalShellData
    params: PhysicalParams
    alpha_t: np.ndarray       # α(t) = K_phys·γ/λ(t)
    delta_t: np.ndarray       # δ(t) = 1/4 - α(t)²
    ews: EWSResult            # running-window EWS
    detection: dict           # detection test results
    tipping: Optional[TippingEstimate] = None


# ═══════════════════════════════════════════════════════════════
# 2. Data Loading
# ═══════════════════════════════════════════════════════════════

def load_csv(filepath: str, alt_min: float = 0, alt_max: float = 2000,
             shell_name: str = "custom") -> OrbitalShellData:
    """
    Load orbital debris data from CSV.

    Expected columns (flexible naming):
      year (or time, date)
      active_satellites (or Q1, active, satellites, payloads)
      debris_count (or Q2, debris, fragments)
      launches (or launch_rate, lambda)

    Optional columns:
      frag_time, frag_q2_before, frag_produced  (fragmentation events)
    """
    import csv

    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if len(rows) == 0:
        raise ValueError(f"Empty CSV: {filepath}")

    # Flexible column matching
    cols = list(rows[0].keys())
    def find_col(candidates):
        for c in candidates:
            for col in cols:
                if c.lower() in col.lower():
                    return col
        return None

    time_col = find_col(['year', 'time', 'date'])
    q1_col = find_col(['active_satellite', 'Q1', 'active', 'satellite', 'payload'])
    q2_col = find_col(['debris_count', 'Q2', 'debris', 'fragment'])
    launch_col = find_col(['launch', 'lambda'])

    if time_col is None:
        raise ValueError(f"No time column found. Available: {cols}")
    if q2_col is None:
        raise ValueError(f"No debris column found. Available: {cols}")

    times = np.array([float(r[time_col]) for r in rows])
    Q2 = np.array([float(r[q2_col]) for r in rows])
    Q1 = np.array([float(r[q1_col]) for r in rows]) if q1_col else np.zeros_like(times)
    launches = np.array([float(r[launch_col]) for r in rows]) if launch_col else np.zeros_like(times)

    # Compute launch rate from cumulative or direct
    if np.all(np.diff(launches) >= 0) and launches[-1] > launches[0] * 2:
        # Looks cumulative — take differences
        launch_rate = np.gradient(launches, times)
    else:
        launch_rate = launches.copy()

    # Ensure positive
    launch_rate = np.maximum(launch_rate, 1.0)

    dt = np.median(np.diff(times))

    # Check for fragmentation event columns
    frag_col = find_col(['frag_time'])
    frag_data = None
    if frag_col:
        frag_times = []
        frag_q2_before = []
        frag_produced = []
        for r in rows:
            if r.get(frag_col) and float(r[frag_col]) > 0:
                frag_times.append(float(r[frag_col]))
                frag_q2_before.append(float(r.get(find_col(['frag_q2_before', 'frag_before']) or '', 0)))
                frag_produced.append(float(r.get(find_col(['frag_produced', 'frag_count']) or '', 0)))
        if frag_times:
            frag_data = (np.array(frag_times), np.array(frag_q2_before),
                         np.array(frag_produced))

    shell = OrbitalShellData(
        times=times, Q1=Q1, Q2=Q2, launches=launches,
        launch_rate=launch_rate, alt_min=alt_min, alt_max=alt_max,
        shell_name=shell_name, dt=dt,
    )
    if frag_data:
        shell.frag_times, shell.frag_debris_before, shell.frag_debris_produced = frag_data

    return shell


def generate_demo_data() -> OrbitalShellData:
    """
    Generate synthetic "realistic" debris data loosely inspired by
    the 500-600km LEO shell, 1960-2025.

    Includes:
      - Slow growth 1960-2000
      - Acceleration 2000-2020 (mega-constellation era)
      - Two shock events (modeled on 2007 ASAT + 2009 Iridium-Cosmos)
      - Background collision rate ε = 0.01
    """
    rng = np.random.RandomState(42)

    dt = 0.25  # quarterly resolution
    times = np.arange(1960, 2026, dt)
    n_t = len(times)

    # Active satellites: slow growth then exponential
    Q1 = np.zeros(n_t)
    for i, t in enumerate(times):
        if t < 2000:
            Q1[i] = 50 + 5 * (t - 1960)
        elif t < 2015:
            Q1[i] = 250 + 30 * (t - 2000)
        else:
            Q1[i] = 700 + 300 * (t - 2015)  # mega-constellation ramp

    # Launch rate (per year)
    launch_rate = np.gradient(Q1, dt) + 20  # replacement + growth
    launch_rate = np.maximum(launch_rate, 10)

    # Debris: starts from background, grows with collisions
    gamma = 0.05  # 20-year average lifetime at ~550km
    epsilon = 0.01
    Q2 = np.zeros(n_t)
    Q2[0] = 5

    # K_phys for this shell (the "true" value we'll try to recover)
    K_phys_true = 800

    for i in range(1, n_t):
        Lambda = Q1[i - 1]  # throughput ≈ active satellites
        n2hi = Lambda / gamma
        K = K_phys_true
        q2 = Q2[i - 1]

        # Hill routing probability
        p_route = epsilon + (1 - epsilon) * q2**2 / (q2**2 + K**2 + 1e-10)

        # Drift + noise
        inflow = Lambda * p_route
        outflow = gamma * q2
        drift = (inflow - outflow) * dt
        noise = np.sqrt(max(inflow + outflow, 1)) * np.sqrt(dt) * rng.randn()

        Q2[i] = max(0, q2 + drift + noise)

        # Shock events
        if abs(times[i] - 2007.1) < dt / 2:
            Q2[i] += 3400  # ASAT test analog
        if abs(times[i] - 2009.2) < dt / 2:
            Q2[i] += 2300  # Collision analog

    # Fragmentation events
    frag_times = np.array([2007.1, 2009.2])
    frag_q2_before = np.array([Q2[np.argmin(np.abs(times - 2007.0))],
                                Q2[np.argmin(np.abs(times - 2009.1))]])
    frag_produced = np.array([3400, 2300])

    return OrbitalShellData(
        times=times, Q1=Q1, Q2=Q2,
        launches=np.cumsum(launch_rate * dt),
        launch_rate=launch_rate,
        alt_min=500, alt_max=600,
        shell_name="500-600km (demo)",
        dt=dt,
        frag_times=frag_times,
        frag_debris_before=frag_q2_before,
        frag_debris_produced=frag_produced,
    )


# ═══════════════════════════════════════════════════════════════
# 3. Shock Event Detection and Removal
# ═══════════════════════════════════════════════════════════════

def detect_shocks(Q2: np.ndarray, times: np.ndarray, dt: float,
                  threshold_sigma: float = 5.0) -> dict:
    """
    Detect sudden jumps in the debris time series (fragmentation events).

    These are NOT part of the diffusive dynamics and must be removed
    before fitting the OU model.

    Args:
        Q2: debris time series
        times: time array
        dt: time step
        threshold_sigma: number of standard deviations for detection

    Returns:
        dict with shock_times, shock_magnitudes, Q2_cleaned
    """
    dQ = np.diff(Q2)
    med = np.median(dQ)
    mad = np.median(np.abs(dQ - med)) * 1.4826  # robust σ estimate

    shock_idx = np.where(np.abs(dQ - med) > threshold_sigma * mad)[0]

    shock_times = times[shock_idx]
    shock_magnitudes = dQ[shock_idx]

    # Clean: replace shocks with interpolated values
    Q2_clean = Q2.copy()
    for idx in shock_idx:
        if idx > 0 and idx < len(Q2) - 1:
            # Remove the jump: set subsequent values lower by the shock magnitude
            Q2_clean[idx + 1:] -= dQ[idx] - med

    # Ensure non-negative
    Q2_clean = np.maximum(Q2_clean, 0)

    return {
        "shock_times": shock_times,
        "shock_magnitudes": shock_magnitudes,
        "shock_indices": shock_idx,
        "Q2_cleaned": Q2_clean,
        "n_shocks": len(shock_idx),
    }


# ═══════════════════════════════════════════════════════════════
# 4. Physical Parameter Estimation
# ═══════════════════════════════════════════════════════════════

def estimate_gamma(Q2: np.ndarray, times: np.ndarray,
                   shock_info: dict) -> float:
    """
    Estimate debris decay rate γ from observed debris decline.

    Method 1: From post-shock exponential decay tails.
    Method 2: From any sustained declining period in Q2.

    At 500-600km, atmospheric drag gives ~15-25 year lifetimes,
    so γ ≈ 0.04-0.07/yr.
    """
    gammas = []

    # Method 1: From shock decay tails (original)
    for i, s_idx in enumerate(shock_info['shock_indices']):
        if s_idx >= len(times) - 10:
            continue
        next_shock = len(times)
        for j in shock_info['shock_indices']:
            if j > s_idx + 5:
                next_shock = j
                break
        tail_end = min(next_shock, s_idx + int(20 / np.median(np.diff(times))))
        tail_Q2 = Q2[s_idx + 1:tail_end]
        tail_t = times[s_idx + 1:tail_end] - times[s_idx]
        if len(tail_Q2) < 5 or tail_Q2[0] <= 0:
            continue
        log_Q2 = np.log(np.maximum(tail_Q2, 1))
        try:
            coeffs = np.polyfit(tail_t, log_Q2, 1)
            gamma_est = -coeffs[0]
            if 0.01 < gamma_est < 0.5:
                gammas.append(gamma_est)
        except Exception:
            pass

    # Method 2: Find sustained declining periods in Q2
    # (works even without detected shocks)
    dQ = np.diff(Q2)
    for start in range(len(dQ)):
        # Look for runs of consecutive decline
        run = 0
        while start + run < len(dQ) and dQ[start + run] < 0:
            run += 1
        if run >= 5 and Q2[start] > 50:
            segment_Q2 = Q2[start:start + run + 1]
            segment_t = times[start:start + run + 1] - times[start]
            log_Q2 = np.log(np.maximum(segment_Q2, 1))
            try:
                coeffs = np.polyfit(segment_t, log_Q2, 1)
                gamma_est = -coeffs[0]
                if 0.01 < gamma_est < 0.3:
                    gammas.append(gamma_est)
            except Exception:
                pass

    if gammas:
        result = np.median(gammas)
        print(f"    (estimated from {len(gammas)} decay segments)")
        return result
    else:
        warnings.warn("Could not estimate γ from data; using default 0.05/yr")
        return 0.05


def estimate_epsilon(Q2_clean: np.ndarray, Q1: np.ndarray,
                     gamma: float) -> float:
    """
    Estimate baseline collision probability ε.

    In the model, ε is the probability that a departing satellite
    produces a debris fragment even when Q2 ≈ 0 (no cascade).

    We estimate it from the steady-state relationship in a period where:
      - Q1 is substantial (enough active satellites)
      - Q2 is moderate and stable (not dominated by recent shocks)
      - ε·Λ ≈ γ·Q2 → ε ≈ γ·Q2/Λ

    Key: Λ here is the TOTAL object throughput, not just active satellites.
    For the ε estimation we use a recent stable period where Q1 is large.
    """
    # Use a period where Q1 is substantial AND Q2 is relatively stable
    # This avoids the early era where Q1 ≈ 5 and Q2 ≈ 100 (debris from
    # explosions of rocket bodies, not from the few active sats)
    q1_threshold = np.percentile(Q1[Q1 > 0], 50) if np.any(Q1 > 0) else 10
    q1_threshold = max(q1_threshold, 50)  # need at least 50 active sats

    good = (Q1 >= q1_threshold) & (Q2_clean > 10)

    if np.sum(good) >= 3:
        Lambda = np.maximum(Q1[good], 1.0)
        eps_estimates = gamma * Q2_clean[good] / Lambda
        eps_estimates = eps_estimates[(eps_estimates > 0) & (eps_estimates < 1)]

        if len(eps_estimates) > 0:
            result = np.median(eps_estimates)
            # Sanity: ε should be small (0.001 - 0.1)
            result = np.clip(result, 0.001, 0.2)
            return result

    # Fallback: use a physically reasonable default
    # At 500-600km, conjunction rate × collision probability ≈ 0.01-0.05
    warnings.warn("Could not estimate ε reliably; using default 0.01")
    return 0.01


def calibrate_K_phys(Q2: np.ndarray, Q1: np.ndarray, times: np.ndarray,
                     gamma: float, epsilon: float,
                     frag_times=None, frag_q2_before=None,
                     frag_produced=None) -> PhysicalParams:
    """
    Calibrate K_phys from the relationship between debris count and
    new-fragment production rate.

    Method 1: From fragmentation events — the production rate scales
    as Q2²/(Q2² + K²). Fit K from observed (Q2, production_rate) pairs.

    Method 2: From the steady-state balance — in periods where Q2 is
    approximately stable, Λ·p̃(Q2) ≈ γ·Q2. Solve for K.

    Method 3: Theoretical — from orbital mechanics parameters.
    """
    K_estimates = []

    # Method 1: From fragmentation events
    if frag_times is not None and len(frag_times) > 0:
        for i in range(len(frag_times)):
            q2 = frag_q2_before[i]
            produced = frag_produced[i]
            if q2 > 0 and produced > 0:
                # The production rate at Q2 is proportional to Q2²/(Q2²+K²)
                # If we know the rate and Q2, solve for K:
                # rate ∝ Q2²/(Q2²+K²) → K² = Q2²·(max_rate/rate - 1)
                # We don't know max_rate, but can use relative scaling
                pass  # need multiple events for this

    # Method 2: Steady-state balance
    # p̃(Q2) = γ·Q2/Λ → ε + (1-ε)·Q2²/(Q2²+K²) = γ·Q2/Λ
    # Solve for K² = (1-ε)·Q2² / (γ·Q2/Λ - ε) - Q2²
    Lambda = np.maximum(Q1, 1.0)
    for i in range(len(Q2)):
        q2 = Q2[i]
        lam = Lambda[i]
        if q2 < 10 or lam < 10:
            continue

        rhs = gamma * q2 / lam  # = p̃(Q2)
        if rhs <= epsilon or rhs >= 1.0:
            continue

        # (1-ε)·Q2²/(Q2²+K²) = rhs - ε
        # K² = (1-ε)·Q2²/(rhs - ε) - Q2²
        K_sq = (1 - epsilon) * q2**2 / (rhs - epsilon) - q2**2
        if K_sq > 0:
            K_estimates.append(np.sqrt(K_sq))

    if len(K_estimates) > 5:
        K_phys = np.median(K_estimates)
        K_lo = np.percentile(K_estimates, 5)
        K_hi = np.percentile(K_estimates, 95)
    else:
        # Fallback: estimate from the debris level at which growth
        # accelerated noticeably
        dQ2 = np.gradient(Q2, times)
        # K is roughly where the growth rate inflects
        accel = np.gradient(dQ2, times)
        peak_idx = np.argmax(accel[len(accel) // 4:]) + len(accel) // 4
        K_phys = Q2[peak_idx] if Q2[peak_idx] > 0 else 500
        K_lo = K_phys * 0.5
        K_hi = K_phys * 2.0
        warnings.warn(f"K_phys estimated from growth inflection: {K_phys:.0f}")

    lambda_crit = 2 * K_phys * gamma

    return PhysicalParams(
        gamma=gamma,
        epsilon=epsilon,
        K_phys=K_phys,
        K_phys_ci=(K_lo, K_hi),
        lambda_crit=lambda_crit,
        method="steady_state" if len(K_estimates) > 5 else "inflection",
    )


# ═══════════════════════════════════════════════════════════════
# 5. Compute α(t) and δ(t)
# ═══════════════════════════════════════════════════════════════

def compute_alpha_delta(shell: OrbitalShellData,
                        params: PhysicalParams) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute the time-varying bifurcation parameters.

    α(t) = K_phys · γ / Λ(t)

    where Λ(t) = Q₁(t) is the active satellite count (throughput),
    NOT the launch rate. The throughput is approximately n in the HW regime.

    δ(t) = 1/4 - α(t)²

    Returns:
        alpha_t, delta_t
    """
    # Λ = active satellites (throughput), not launch rate
    Lambda_t = np.maximum(shell.Q1, 1.0)
    alpha_t = params.K_phys * params.gamma / Lambda_t
    delta_t = 0.25 - alpha_t**2

    return alpha_t, delta_t


# ═══════════════════════════════════════════════════════════════
# 6. Single-Timeseries EWS (the Ditlevsen method)
# ═══════════════════════════════════════════════════════════════

def run_ews_analysis(shell: OrbitalShellData, params: PhysicalParams,
                     Tw: float = 10.0, baseline_end: float = 1990.0,
                     confidence: float = 0.95) -> RealDataEWS:
    """
    Full EWS analysis on a single observed debris time series.

    This is the direct analog of Ditlevsen's analysis of the AMOC
    fingerprint, but applied to Q2(t).

    Args:
        shell: orbital shell data
        params: estimated physical parameters
        Tw: running window size (years)
        baseline_end: year before which data is treated as baseline
        confidence: confidence level for detection

    Returns:
        RealDataEWS with all results
    """
    from scipy.stats import norm

    alpha_t, delta_t = compute_alpha_delta(shell, params)

    # Detect and remove shock events
    shock_info = detect_shocks(shell.Q2, shell.times, shell.dt)
    Q2_clean = shock_info['Q2_cleaned']

    print(f"  Detected {shock_info['n_shocks']} shock events")
    if shock_info['n_shocks'] > 0:
        for t, m in zip(shock_info['shock_times'], shock_info['shock_magnitudes']):
            print(f"    t = {t:.2f}, ΔQ₂ = {m:.0f}")

    # Running-window EWS on cleaned time series
    ews = compute_running_window_ews(Q2_clean, shell.times, Tw=Tw,
                                      dt=shell.dt, detrend=True)

    # Detection test
    q = norm.ppf(confidence)
    bl_mask = ews.times < baseline_end
    detection = {
        "variance": {"detected": False, "time": None},
        "autocorrelation": {"detected": False, "time": None},
    }

    if np.any(bl_mask):
        # Variance baseline
        bl_var = np.mean(ews.variance[bl_mask])
        bl_alpha_r = np.mean(ews.alpha_restore[bl_mask])
        bl_se_var = se_variance(bl_var, bl_alpha_r, Tw)

        # Test each post-baseline point
        for i, t in enumerate(ews.times):
            if t < baseline_end:
                continue
            curr_var = ews.variance[i]
            curr_alpha_r = ews.alpha_restore[i]
            curr_se_var = se_variance(curr_var, curr_alpha_r, Tw)
            if curr_var - bl_var > q * (bl_se_var + curr_se_var):
                if not detection["variance"]["detected"]:
                    detection["variance"]["detected"] = True
                    detection["variance"]["time"] = t
                    break

        # Autocorrelation baseline
        bl_ac = np.mean(ews.autocorrelation[bl_mask])
        for i, t in enumerate(ews.times):
            if t < baseline_end:
                continue
            curr_ac = ews.autocorrelation[i]
            bl_se_ac = se_autocorrelation(bl_alpha_r, shell.dt, Tw)
            curr_se_ac = se_autocorrelation(ews.alpha_restore[i], shell.dt, Tw)
            if curr_ac - bl_ac > q * (bl_se_ac + curr_se_ac):
                if not detection["autocorrelation"]["detected"]:
                    detection["autocorrelation"]["detected"] = True
                    detection["autocorrelation"]["time"] = t
                    break

        detection["baseline_variance"] = bl_var
        detection["baseline_ac"] = bl_ac
        detection["baseline_alpha_r"] = bl_alpha_r

    # Tipping time estimate (if EWS detected)
    tipping = None
    post_mask = ews.times > baseline_end
    if np.any(post_mask) and np.any(ews.A_delta[post_mask] > 0):
        tipping = estimate_tipping_moment(
            ews.A_delta[post_mask], ews.times[post_mask]
        )

    return RealDataEWS(
        shell=shell,
        params=params,
        alpha_t=alpha_t,
        delta_t=delta_t,
        ews=ews,
        detection=detection,
        tipping=tipping,
    )


# ═══════════════════════════════════════════════════════════════
# 7. Plotting
# ═══════════════════════════════════════════════════════════════

def plot_results(result: RealDataEWS, shock_info: dict,
                 save_path: str = None):
    """Publication-quality figure showing the full EWS analysis."""

    shell = result.shell
    ews = result.ews
    det = result.detection

    fig = plt.figure(figsize=(18, 16))
    gs = GridSpec(3, 3, hspace=0.38, wspace=0.35,
                  left=0.07, right=0.96, top=0.94, bottom=0.05)

    # (a) Raw debris time series with shocks marked
    ax = fig.add_subplot(gs[0, 0])
    ax.plot(shell.times, shell.Q2, color=COLORS['orange'], lw=1.5,
            label='Q₂(t) — tracked debris')
    ax.plot(shell.times, shock_info['Q2_cleaned'], color=COLORS['cyan'],
            lw=1, alpha=0.7, label='cleaned (shocks removed)')
    for t in shock_info['shock_times']:
        ax.axvline(t, color=COLORS['red'], ls=':', lw=1, alpha=0.5)
    ax.set_xlabel('Year')
    ax.set_ylabel('Debris count')
    ax.set_title(f'(a) Debris in {shell.shell_name}')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (b) Active satellites and launch rate
    ax = fig.add_subplot(gs[0, 1])
    ax.plot(shell.times, shell.Q1, color=COLORS['blue'], lw=2,
            label='Active satellites Q₁')
    ax2 = ax.twinx()
    ax2.plot(shell.times, shell.launch_rate, color=COLORS['green'], lw=1.5,
             ls=':', label='λ(t)')
    ax2.set_ylabel('Launch rate λ(t)', color=COLORS['green'])
    ax2.tick_params(axis='y', labelcolor=COLORS['green'])
    ax.set_xlabel('Year')
    ax.set_ylabel('Active satellites')
    ax.set_title('(b) Constellation and launch rate')
    ax.legend(fontsize=8, loc='upper left')
    ax.grid(True)

    # (c) α(t) and δ(t)
    ax = fig.add_subplot(gs[0, 2])
    ax.plot(shell.times, result.alpha_t, color=COLORS['purple'], lw=2,
            label='α(t) = K·γ/Λ(t)')
    ax.axhline(0.5, color=COLORS['red'], ls='--', lw=1.5, alpha=0.7,
               label='αc = 0.5')
    ax.axhline(np.sqrt(result.params.epsilon), color=COLORS['blue'],
               ls=':', lw=1, alpha=0.7, label=f'√ε = {np.sqrt(result.params.epsilon):.3f}')
    ax.fill_between(shell.times, result.alpha_t, 0.5,
                    where=result.alpha_t >= 0.5,
                    color=COLORS['green'], alpha=0.1)
    ax.fill_between(shell.times, 0.5, result.alpha_t,
                    where=result.alpha_t < 0.5,
                    color=COLORS['red'], alpha=0.1)
    ax.set_xlabel('Year')
    ax.set_ylabel('α(t)')
    ax.set_title('(c) Distance to bifurcation')
    ax.legend(fontsize=7)
    ax.grid(True)

    # (d) Running-window variance (EWS #1)
    ax = fig.add_subplot(gs[1, 0])
    ax.plot(ews.times, ews.variance, color=COLORS['orange'], lw=1.5,
            label='variance')
    if 'baseline_variance' in det:
        bl_var = det['baseline_variance']
        ax.axhline(bl_var, color=COLORS['gray'], ls='-', lw=1, alpha=0.5,
                   label=f'baseline = {bl_var:.0f}')
    if det['variance']['detected']:
        ax.axvline(det['variance']['time'], color=COLORS['green'], lw=2,
                   alpha=0.7, label=f'detected {det["variance"]["time"]:.1f}')
    ax.set_xlabel('Year')
    ax.set_ylabel('Variance')
    ax.set_title('(d) EWS #1: Variance (loss of resilience)')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (e) Running-window autocorrelation (EWS #2)
    ax = fig.add_subplot(gs[1, 1])
    ax.plot(ews.times, ews.autocorrelation, color=COLORS['cyan'], lw=1.5,
            label='lag-1 autocorrelation')
    ax.axhline(1.0, color=COLORS['red'], ls=':', lw=1, alpha=0.5)
    if 'baseline_ac' in det:
        ax.axhline(det['baseline_ac'], color=COLORS['gray'], ls='-', lw=1,
                   alpha=0.5)
    if det['autocorrelation']['detected']:
        ax.axvline(det['autocorrelation']['time'], color=COLORS['green'],
                   lw=2, alpha=0.7,
                   label=f'detected {det["autocorrelation"]["time"]:.1f}')
    ax.set_xlabel('Year')
    ax.set_ylabel('Autocorrelation')
    ax.set_title('(e) EWS #2: Autocorrelation (critical slowing down)')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (f) Restoring rate → 0
    ax = fig.add_subplot(gs[1, 2])
    ax.plot(ews.times, ews.alpha_restore, color=COLORS['green'], lw=1.5,
            label='α_restore(t)')
    ax.axhline(0, color=COLORS['red'], ls='--', lw=1, alpha=0.7)
    ax.set_xlabel('Year')
    ax.set_ylabel('Restoring rate')
    ax.set_title('(f) Restoring rate (→ 0 = critical slowing down)')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (g) Aδ(t) and tipping time estimate
    ax = fig.add_subplot(gs[2, 0])
    ax.plot(ews.times, ews.A_delta, color=COLORS['pink'], lw=1.5,
            label='Aδ(t) = α_r²/4')
    if result.tipping and np.isfinite(result.tipping.t_c):
        t_post = ews.times[ews.times > det.get('baseline_end', 1990)]
        if len(t_post) > 0:
            slope = result.tipping.params.get('slope', 0)
            intercept = result.tipping.params.get('intercept', 0)
            fit = slope * t_post + intercept
            ax.plot(t_post, fit, '--', color=COLORS['red'], lw=2,
                    label=f'fit → tc = {result.tipping.t_c:.0f}')
            ax.axvline(result.tipping.t_c, color=COLORS['red'], ls=':',
                       lw=1.5, alpha=0.7)
    ax.axhline(0, color=COLORS['gray'], ls=':', lw=1)
    ax.set_xlabel('Year')
    ax.set_ylabel('Aδ(t)')
    ax.set_title('(g) Tipping-time estimate')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (h) Physical parameters summary
    ax = fig.add_subplot(gs[2, 1])
    ax.axis('off')
    p = result.params
    text = (
        f"Physical parameters\n"
        f"{'─' * 35}\n"
        f"Shell: {shell.shell_name}\n"
        f"γ = {p.gamma:.4f} /yr (decay rate)\n"
        f"ε = {p.epsilon:.4f} (baseline collision prob)\n"
        f"K_phys = {p.K_phys:.0f} [{p.K_phys_ci[0]:.0f}, {p.K_phys_ci[1]:.0f}]\n"
        f"λ_crit = {p.lambda_crit:.0f} (bifurcation)\n"
        f"Method: {p.method}\n\n"
        f"Current state\n"
        f"{'─' * 35}\n"
        f"α(now) = {result.alpha_t[-1]:.3f}\n"
        f"δ(now) = {result.delta_t[-1]:.4f}\n"
        f"Regime: {'BISTABLE' if result.alpha_t[-1] < 0.5 else 'monostable'}\n"
    )
    if result.tipping and np.isfinite(result.tipping.t_c):
        text += (
            f"\nTipping estimate\n"
            f"{'─' * 35}\n"
            f"tc = {result.tipping.t_c:.0f}\n"
            f"95% CI: [{result.tipping.ci_95[0]:.0f}, {result.tipping.ci_95[1]:.0f}]\n"
        )

    v_det = det['variance']
    a_det = det['autocorrelation']
    v_txt = f'YES at {v_det["time"]:.1f}' if v_det['detected'] else 'not detected'
    a_txt = f'YES at {a_det["time"]:.1f}' if a_det['detected'] else 'not detected'
    text += (
        f"\nEWS detection\n"
        f"{'─' * 35}\n"
        f"Variance: {v_txt}\n"
        f"Autocorrelation: {a_txt}\n"
    )

    ax.text(0.05, 0.95, text, transform=ax.transAxes, fontsize=11,
            fontfamily='monospace', color=COLORS['cyan'],
            verticalalignment='top')

    # (i) Q2/n₂ʰⁱ — normalized debris
    ax = fig.add_subplot(gs[2, 2])
    Lambda = np.maximum(shell.Q1, 1.0)
    n2hi = Lambda / result.params.gamma
    q2_norm = shell.Q2 / np.maximum(n2hi, 1.0)
    ax.plot(shell.times, q2_norm, color=COLORS['orange'], lw=1.5,
            label='Q₂ / n₂ʰⁱ')
    ax.axhline(result.params.epsilon, color=COLORS['blue'], ls='-', lw=1,
               alpha=0.7, label=f'ε = {result.params.epsilon:.3f}')
    # Plot threshold if bistable
    for i in range(len(shell.times)):
        a = result.alpha_t[i]
        if a < 0.5:
            disc = 1 - 4 * a**2
            if disc > 0:
                qm = (1 - np.sqrt(disc)) / 2
                ax.plot(shell.times[i], qm, '.', color=COLORS['red'],
                        ms=0.5, alpha=0.3)
    ax.set_xlabel('Year')
    ax.set_ylabel('q₂ / n₂ʰⁱ (normalized)')
    ax.set_title('(i) Normalized debris vs thresholds')
    ax.legend(fontsize=8)
    ax.set_ylim(0, min(q2_norm.max() * 1.2, 1.0))
    ax.grid(True)

    fig.suptitle(f'Orbital Debris EWS Analysis — {shell.shell_name}\n'
                 f'K_phys={result.params.K_phys:.0f}, '
                 f'γ={result.params.gamma:.3f}/yr, '
                 f'ε={result.params.epsilon:.4f}',
                 fontsize=14, fontweight='bold', color='white')

    path = save_path or os.path.join(OUT_DIR, 'real_data_ews.png')
    fig.savefig(path, dpi=180)
    print(f"  Saved: {path}")
    plt.close()


# ═══════════════════════════════════════════════════════════════
# 8. Full Pipeline
# ═══════════════════════════════════════════════════════════════

def run_pipeline(shell: OrbitalShellData, Tw: float = 10.0,
                 baseline_end: float = 1990.0,
                 confidence: float = 0.95,
                 debris_multiplier: float = 1.0,
                 altitude: float = None):
    """
    Run the complete EWS pipeline on observed orbital debris data.

    Args:
        shell: orbital shell data
        Tw: running window size (years)
        baseline_end: year before which data is baseline
        confidence: confidence level
        debris_multiplier: scaling factor for Q2 (MASTER-8: ~50x)
        altitude: orbital altitude in km. If provided, uses the
            atmospheric model for γ and K_phys instead of estimating
            from data. Also prints altitude comparison table.

    Steps:
      1. Apply debris multiplier to Q2
      2. Detect and remove shock events
      3. Estimate γ, ε, K_phys
      4. Compute α(t) and δ(t)
      5. Run Ditlevsen-style EWS
      6. Estimate tipping time
      7. Generate diagnostic plots
    """
    print("\n" + "=" * 70)
    print(f"  ORBITAL DEBRIS EWS PIPELINE")
    print(f"  Shell: {shell.shell_name} ({shell.alt_min}-{shell.alt_max} km)")
    print(f"  Time range: {shell.times[0]:.1f} - {shell.times[-1]:.1f}")
    print(f"  Data points: {len(shell.times)}, dt = {shell.dt:.3f} yr")
    if altitude is not None:
        print(f"  Altitude model: {altitude:.0f} km")
    if debris_multiplier != 1.0:
        print(f"  Debris multiplier: {debris_multiplier:.0f}× "
              f"(estimating 1-10cm from tracked >10cm)")
    print("=" * 70)

    # Step 0: Apply debris multiplier
    if debris_multiplier != 1.0:
        print(f"\n  Step 0: Scaling Q₂ by {debris_multiplier:.0f}× "
              f"(MASTER/ORDEM statistical estimate)")
        print(f"    Tracked Q₂ range: {shell.Q2.min():.0f} - {shell.Q2.max():.0f}")
        shell.Q2 = (shell.Q2 * debris_multiplier).astype(shell.Q2.dtype)
        print(f"    Estimated Q₂ range: {shell.Q2.min():.0f} - {shell.Q2.max():.0f}")
        if shell.frag_debris_produced is not None:
            shell.frag_debris_produced = shell.frag_debris_produced * debris_multiplier

    # Step 1: Detect shocks
    print("\n  Step 1: Detecting shock events...")
    shock_info = detect_shocks(shell.Q2, shell.times, shell.dt)
    Q2_clean = shock_info['Q2_cleaned']

    # Step 2: Estimate physical parameters
    print("  Step 2: Estimating physical parameters...")

    if altitude is not None:
        # Use atmospheric model for γ
        gamma = gamma_from_altitude(altitude)
        tau = debris_lifetime(altitude)
        print(f"    γ = {gamma:.4f} /yr (from atmospheric model at {altitude:.0f} km)")
        print(f"    Debris lifetime ≈ {tau:.1f} yr")
    else:
        gamma = estimate_gamma(shell.Q2, shell.times, shock_info)
        print(f"    γ = {gamma:.4f} /yr (estimated from data)")

    epsilon = estimate_epsilon(Q2_clean, shell.Q1, gamma)
    print(f"    ε = {epsilon:.4f} (baseline collision probability)")

    if altitude is not None:
        # Use altitude model for K_phys
        K_phys_model = K_phys_from_altitude(altitude)
        params = PhysicalParams(
            gamma=gamma, epsilon=epsilon,
            K_phys=K_phys_model,
            K_phys_ci=(K_phys_model * 0.7, K_phys_model * 1.3),
            lambda_crit=2 * K_phys_model * gamma,
            method=f"altitude_model ({altitude:.0f} km)",
        )
        print(f"    K_phys = {params.K_phys:.0f} "
              f"(from altitude model at {altitude:.0f} km)")
    else:
        params = calibrate_K_phys(Q2_clean, shell.Q1, shell.times,
                                   gamma, epsilon,
                                   shell.frag_times, shell.frag_debris_before,
                                   shell.frag_debris_produced)
        print(f"    K_phys = {params.K_phys:.0f} "
              f"[{params.K_phys_ci[0]:.0f}, {params.K_phys_ci[1]:.0f}] "
              f"(method: {params.method})")
    print(f"    λ_crit = {params.lambda_crit:.0f} (bifurcation launch rate)")

    # Critical constellation sizes
    n_bif = 2 * params.K_phys * params.gamma
    n_capture = params.K_phys * params.gamma / np.sqrt(max(epsilon, 1e-6))
    print(f"    n_bif = {n_bif:.0f} (Kessler trap appears)")
    print(f"    n_capture = {n_capture:.0f} (clean state destroyed, ε={epsilon:.3f})")

    # Step 3: Compute α(t), δ(t)
    print("  Step 3: Computing α(t) and δ(t)...")
    alpha_t, delta_t = compute_alpha_delta(shell, params)
    print(f"    Λ(start) = {shell.Q1[0]:.0f}, Λ(end) = {shell.Q1[-1]:.0f}")
    print(f"    α(start) = {alpha_t[0]:.3f}, α(end) = {alpha_t[-1]:.3f}")
    print(f"    δ(end) = {delta_t[-1]:.4f}")
    bif_idx = np.where(alpha_t < 0.5)[0]
    if len(bif_idx) > 0:
        print(f"    Bifurcation crossed at t = {shell.times[bif_idx[0]]:.1f}")
    else:
        print(f"    System is still monostable (α > 0.5)")

    # Step 4: EWS analysis
    print(f"  Step 4: Running EWS analysis (Tw={Tw} yr, baseline < {baseline_end})...")
    result = run_ews_analysis(shell, params, Tw=Tw,
                               baseline_end=baseline_end,
                               confidence=confidence)

    v_det = result.detection['variance']
    a_det = result.detection['autocorrelation']
    v_msg = f'DETECTED at {v_det["time"]:.1f}' if v_det['detected'] else 'not detected'
    a_msg = f'DETECTED at {a_det["time"]:.1f}' if a_det['detected'] else 'not detected'
    print(f"    Variance EWS: {v_msg}")
    print(f"    Autocorrelation EWS: {a_msg}")

    # Step 5: Tipping time
    if result.tipping and np.isfinite(result.tipping.t_c):
        print(f"\n  Step 5: Tipping-time estimate:")
        print(f"    tc = {result.tipping.t_c:.0f}")
        print(f"    95% CI: [{result.tipping.ci_95[0]:.0f}, {result.tipping.ci_95[1]:.0f}]")
    else:
        print(f"\n  Step 5: No tipping time estimated (Aδ not declining)")

    # Step 6: Plot
    print("  Step 6: Generating diagnostic plots...")
    plot_results(result, shock_info)

    # Summary
    print(f"\n  {'='*50}")
    print(f"  SUMMARY")
    print(f"  {'='*50}")
    if alpha_t[-1] > 0.5:
        print(f"  Status: SAFE — monostable (α = {alpha_t[-1]:.3f} > 0.5)")
        print(f"  No Kessler trap exists at current launch rate.")
        print(f"  Bifurcation would require Λ > {params.lambda_crit:.0f}")
        print(f"  Current Λ (active satellites) ≈ {shell.Q1[-1]:.0f}")
    elif alpha_t[-1] > np.sqrt(epsilon):
        print(f"  Status: CAUTION — bistable (α = {alpha_t[-1]:.3f})")
        print(f"  Kessler trap exists but barrier holds.")
        print(f"  Noise-induced capture unlikely at this scale.")
        print(f"  Deterministic capture at α ≈ √ε = {np.sqrt(epsilon):.3f}")
    else:
        print(f"  Status: DANGER — baseline approaching threshold")
        print(f"  α = {alpha_t[-1]:.3f} < √ε = {np.sqrt(epsilon):.3f}")
        print(f"  Deterministic capture imminent or underway.")

    print(f"\n  Critical constellation sizes:")
    print(f"    n_bif    = {n_bif:.0f} (Kessler trap appears)")
    print(f"    n_capture = {n_capture:.0f} (clean state destroyed)")
    print(f"    n_current = {shell.Q1[-1]:.0f} (current constellation)")
    if shell.Q1[-1] > n_capture:
        print(f"    ⚠  Current constellation EXCEEDS n_capture by "
              f"{shell.Q1[-1]/n_capture:.1f}×")
    elif shell.Q1[-1] > n_bif:
        print(f"    ⚠  Current constellation exceeds n_bif but below n_capture")

    # Altitude comparison table
    if altitude is not None:
        print_altitude_comparison(epsilon=epsilon,
                                  K_phys_ref=params.K_phys)

    return result


# ═══════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="EWS analysis on orbital debris time series"
    )
    parser.add_argument("--csv", type=str, default=None,
                        help="Path to CSV with debris data")
    parser.add_argument("--demo", action="store_true",
                        help="Run on synthetic demo data")
    parser.add_argument("--alt_min", type=float, default=0,
                        help="Altitude band lower bound (km)")
    parser.add_argument("--alt_max", type=float, default=2000,
                        help="Altitude band upper bound (km)")
    parser.add_argument("--Tw", type=float, default=10.0,
                        help="Running window size (years)")
    parser.add_argument("--baseline", type=float, default=1990.0,
                        help="Baseline end year")
    parser.add_argument("--debris_multiplier", type=float, default=1.0,
                        help="Scale Q2 to estimate untracked 1-10cm debris. "
                             "MASTER-8 suggests ~50x globally. "
                             "Use 1.0 for tracked-only (>10cm).")
    parser.add_argument("--altitude", type=float, default=None,
                        help="Orbital altitude in km. Uses atmospheric model "
                             "for γ and K_phys instead of estimating from data. "
                             "Also prints altitude comparison table.")
    parser.add_argument("--altitude_table", action="store_true",
                        help="Print altitude comparison table and exit. "
                             "Use with --epsilon to set ε (default 0.01).")
    parser.add_argument("--epsilon", type=float, default=None,
                        help="Override ε (baseline collision probability) "
                             "for altitude table. Default: estimated from data.")
    args = parser.parse_args()

    # Standalone altitude table mode
    if args.altitude_table:
        eps = args.epsilon if args.epsilon is not None else 0.01
        print_altitude_comparison(epsilon=eps)
        return

    if args.demo:
        print("  Generating synthetic demo data...")
        shell = generate_demo_data()
    elif args.csv:
        print(f"  Loading data from {args.csv}...")
        shell = load_csv(args.csv, args.alt_min, args.alt_max)
    else:
        print("  No data source specified. Use --demo or --csv <file>")
        print("  Run with --demo to see the pipeline on synthetic data.")
        print("  Run with --altitude_table for altitude comparison.")
        return

    run_pipeline(shell, Tw=args.Tw, baseline_end=args.baseline,
                 debris_multiplier=args.debris_multiplier,
                 altitude=args.altitude)


if __name__ == "__main__":
    main()
