# Early-Warning Signals for Bistability Collapse in a Tandem Network

GPU-accelerated implementation of the Ditlevsen & Ditlevsen (2023) EWS
framework, adapted for the tandem M/M/n/n → M/M/∞ network with
Hill-function state-dependent routing.

## Setup

```bash
# GPU (recommended)
pip install cupy-cuda12x numpy scipy matplotlib

# CPU-only fallback
pip install numpy scipy matplotlib
```

## Usage

```bash
# Run all 4 phases with default parameters (n=1000, B=4096)
python run_experiments.py

# Run a specific phase
python run_experiments.py --phase 1    # EWS validation
python run_experiments.py --phase 2    # Normal-form calibration
python run_experiments.py --phase 3    # Green band diagram
python run_experiments.py --phase 4    # Tipping-time estimation

# Custom parameters
python run_experiments.py --n 1000 --B 8192 --T 1000 --tau_r 500

# Force CPU mode
python run_experiments.py --cpu
```

## Files

| File | Description |
|------|-------------|
| `tandem_sim.py` | GPU simulator: tau-leaping across B replicas via CuPy |
| `ews_analysis.py` | EWS computation: variance, autocorrelation, detection tests |
| `tipping_estimator.py` | Tipping-time estimation: moment-based + MLE + bootstrap |
| `run_experiments.py` | Main runner for all 4 phases with publication-quality plots |

## The Four Phases

### Phase 1 — Validate EWS on Ramped Simulation
Ramp α from 0.3 → 0.5 over [t₀, t₀+τ_r].  
Outputs: sample trajectories, cross-replica variance spike, autocorrelation → 1,
restoring rate → 0, Aδ(t) declining to zero.

### Phase 2 — Calibrate the Normal Form
Run equilibrium at α ∈ {0.15, ..., 0.48}. Verify:
- γ² ~ δ^{-1/2} (variance scaling)
- α_restore² = 4Aδ (linear in δ)
- μ = m + √(δ/A) (square-root law)

### Phase 3 — Green Band Diagram
Compute the range of δ where EWS are both detectable AND not pre-empted
by noise-induced tipping. Analog of Ditlevsen Fig. 4a.

### Phase 4 — Tipping-Time Estimation
Moment-based: regress Aδ(t) on t, find zero crossing.  
MLE: Strang splitting for nonlinear SDE.  
Bootstrap: 200 replications for confidence intervals.

## Key Insight: n-Tipping

At moderate n (e.g., 200), noise-induced tipping causes collapse well
before the deterministic bifurcation at α=0.5. The estimated t_c will
systematically underestimate the true tc. This bias shrinks exponentially
with n because the Kramers barrier grows as exp(n·C·δ^{3/2}).

**Recommended**: run with n ≥ 1000 for meaningful tipping-time estimates.

## Correspondence to Ditlevsen & Ditlevsen (2023)

| This code | Paper |
|-----------|-------|
| `alpha` (Hill param) | λ (control parameter) |
| `delta = 1/4 - alpha²` | λ (bifurcation distance) |
| `alpha_restore` | α (inverse correlation time) |
| `cross-replica variance` | γ² (increased variance = loss of resilience) |
| `cross-replica autocorrelation` | ρ (critical slowing down) |
| `estimate_tipping_moment()` | Fig. 5f (linear regression of Aλ) |
| `estimate_tipping_mle()` | Strang splitting MLE (Supplementary S2) |
| `compute_green_band()` | Fig. 4a (actionable EWS range) |
