"""
Early-Warning Signal (EWS) computation and detection for the tandem network.

Implements:
  - Running-window variance, autocorrelation, OU parameter recovery
  - Cross-replica (instantaneous) variance
  - Ditlevsen-style detection tests (Eqs. 7–8)
  - Required window size calculations
  - Baseline comparison with confidence intervals
"""

import numpy as np
from dataclasses import dataclass
from typing import Tuple, Optional


@dataclass
class EWSResult:
    """Container for EWS computed over time."""
    times: np.ndarray            # mid-point of each window
    variance: np.ndarray         # running-window variance
    autocorrelation: np.ndarray  # running-window lag-1 autocorrelation
    alpha_restore: np.ndarray    # inferred OU restoring rate
    sigma_sq: np.ndarray         # inferred OU noise intensity
    A_delta: np.ndarray          # combined bifurcation parameter (α_r²/4)


@dataclass
class CrossReplicaEWS:
    """Container for cross-replica EWS."""
    times: np.ndarray
    variance: np.ndarray         # cross-replica variance at each time
    mean: np.ndarray             # cross-replica mean at each time
    skewness: np.ndarray         # cross-replica skewness


@dataclass
class DetectionResult:
    """Result of EWS detection test."""
    detected: bool
    detection_time: Optional[float]
    p_values: np.ndarray         # p-value at each time point
    ews_values: np.ndarray       # EWS values over time
    baseline_value: float
    baseline_se: float
    confidence_level: float


# ═══════════════════════════════════════════════════════════════
# 1. Running-Window EWS
# ═══════════════════════════════════════════════════════════════

def compute_running_window_ews(Q2: np.ndarray, times: np.ndarray,
                                Tw: float, dt: float,
                                detrend: bool = True) -> EWSResult:
    """
    Compute EWS within running windows on a SINGLE trajectory
    (or the mean trajectory across replicas).

    Args:
        Q2: (n_times,) time series of station 2 occupancy
        times: (n_times,) corresponding time points
        Tw: window size (in time units)
        dt: time step between observations
        detrend: if True, subtract linear trend within each window

    Returns:
        EWSResult with variance, autocorrelation, and inferred OU parameters
    """
    n = len(Q2)
    hw = int(Tw / (2 * dt))  # half-window in index units

    out_times = []
    out_var = []
    out_ac = []
    out_alpha_r = []
    out_sigma_sq = []
    out_Adelta = []

    for i in range(hw, n - hw):
        window = Q2[i - hw:i + hw].astype(np.float64)
        t_mid = times[i]

        if detrend:
            # Subtract linear trend to avoid inflated variance
            t_win = np.arange(len(window), dtype=np.float64)
            coeffs = np.polyfit(t_win, window, 1)
            window = window - np.polyval(coeffs, t_win)

        # Variance (MLE)
        var = np.var(window, ddof=0)

        # Lag-1 autocorrelation (MLE)
        if var > 1e-30:
            x0 = window[:-1] - np.mean(window)
            x1 = window[1:] - np.mean(window)
            ac = np.sum(x0 * x1) / np.sum(x0 ** 2)
            ac = np.clip(ac, 1e-6, 1.0 - 1e-6)
        else:
            ac = 0.0

        # Infer OU parameters
        alpha_r = -np.log(ac) / dt if ac > 0 else 1e-6
        sigma_sq = 2 * alpha_r * var if alpha_r > 0 else 0.0
        Adelta = alpha_r ** 2 / 4.0

        out_times.append(t_mid)
        out_var.append(var)
        out_ac.append(ac)
        out_alpha_r.append(alpha_r)
        out_sigma_sq.append(sigma_sq)
        out_Adelta.append(Adelta)

    return EWSResult(
        times=np.array(out_times),
        variance=np.array(out_var),
        autocorrelation=np.array(out_ac),
        alpha_restore=np.array(out_alpha_r),
        sigma_sq=np.array(out_sigma_sq),
        A_delta=np.array(out_Adelta),
    )


def compute_running_window_ews_ensemble(Q2: np.ndarray, times: np.ndarray,
                                         Tw: float, dt: float,
                                         basin_mask: Optional[np.ndarray] = None
                                         ) -> EWSResult:
    """
    Compute EWS using MULTIPLE replicas: for each window, pool across
    replicas in the specified basin.

    Args:
        Q2: (n_times, B) array
        times: (n_times,)
        Tw: window size
        dt: time step
        basin_mask: (B,) boolean — True for replicas to include

    Returns:
        EWSResult
    """
    if basin_mask is None:
        basin_mask = np.ones(Q2.shape[1], dtype=bool)

    Q2_sel = Q2[:, basin_mask]
    # Compute replica-mean trajectory, then apply running window
    Q2_mean = np.mean(Q2_sel, axis=1)
    return compute_running_window_ews(Q2_mean, times, Tw, dt, detrend=True)


# ═══════════════════════════════════════════════════════════════
# 2. Cross-Replica EWS (instantaneous — no window needed)
# ═══════════════════════════════════════════════════════════════

def compute_cross_replica_ews(Q2: np.ndarray, times: np.ndarray,
                               basin_mask: Optional[np.ndarray] = None
                               ) -> CrossReplicaEWS:
    """
    Compute instantaneous cross-replica variance at each time point.
    This eliminates the need for a running window.

    Args:
        Q2: (n_times, B) array
        times: (n_times,)
        basin_mask: (B,) boolean — True for replicas to include

    Returns:
        CrossReplicaEWS
    """
    if basin_mask is None:
        basin_mask = np.ones(Q2.shape[1], dtype=bool)

    Q2_sel = Q2[:, basin_mask].astype(np.float64)
    B_eff = Q2_sel.shape[1]

    mean = np.mean(Q2_sel, axis=1)
    var = np.var(Q2_sel, axis=1, ddof=1)

    # Skewness
    centered = Q2_sel - mean[:, None]
    m3 = np.mean(centered ** 3, axis=1)
    std = np.sqrt(var + 1e-30)
    skew = m3 / (std ** 3 + 1e-30)

    return CrossReplicaEWS(
        times=times,
        variance=var,
        mean=mean,
        skewness=skew,
    )


# ═══════════════════════════════════════════════════════════════
# 3. Lag-1 Cross-Replica Autocorrelation
# ═══════════════════════════════════════════════════════════════

def compute_cross_replica_autocorrelation(Q2: np.ndarray,
                                           basin_mask: Optional[np.ndarray] = None
                                           ) -> np.ndarray:
    """
    For each replica, compute lag-1 autocorrelation at each time using
    a (short) local window, then average across replicas.

    Alternative: use the cross-replica covariance between consecutive times:
        ρ(t) = Cov_b(Q2(t), Q2(t-1)) / Var_b(Q2(t))

    This is a cross-time, cross-replica autocorrelation estimator.

    Args:
        Q2: (n_times, B)
        basin_mask: optional

    Returns:
        rho: (n_times,) lag-1 autocorrelation estimate
    """
    if basin_mask is None:
        basin_mask = np.ones(Q2.shape[1], dtype=bool)

    Q2_sel = Q2[:, basin_mask].astype(np.float64)
    n_t = Q2_sel.shape[0]

    rho = np.zeros(n_t)
    for t in range(1, n_t):
        x0 = Q2_sel[t - 1] - np.mean(Q2_sel[t - 1])
        x1 = Q2_sel[t] - np.mean(Q2_sel[t])
        cov = np.mean(x0 * x1)
        var0 = np.var(Q2_sel[t - 1])
        var1 = np.var(Q2_sel[t])
        if var0 > 0 and var1 > 0:
            rho[t] = cov / np.sqrt(var0 * var1)

    return rho


# ═══════════════════════════════════════════════════════════════
# 4. Standard Errors (Ditlevsen Eq. 4)
# ═══════════════════════════════════════════════════════════════

def se_variance(gamma_sq: float, alpha_r: float, Tw: float) -> float:
    """
    Standard error of variance estimator within window Tw.
    Var(γ̂²) ≈ 2(γ²)² / (α · Tw)    [Ditlevsen Eq. 4]
    """
    if alpha_r * Tw < 1e-10:
        return np.inf
    return np.sqrt(2 * gamma_sq ** 2 / (alpha_r * Tw))


def se_autocorrelation(alpha_r: float, dt: float, Tw: float) -> float:
    """
    Standard error of autocorrelation estimator within window Tw.
    Var(ρ̂) ≈ 2α·Δt² / Tw    [Ditlevsen Eq. 4]
    """
    if Tw < 1e-10:
        return np.inf
    return np.sqrt(2 * alpha_r * dt ** 2 / Tw)


def se_cross_replica_variance(gamma_sq: float, B: int) -> float:
    """
    Standard error of cross-replica variance estimator.
    Var(γ̂²_cross) ≈ 2(γ²)² / B
    No time window needed — this is the advantage of multiple replicas.
    """
    return np.sqrt(2 * gamma_sq ** 2 / B)


# ═══════════════════════════════════════════════════════════════
# 5. Detection Test
# ═══════════════════════════════════════════════════════════════

def detect_ews_variance(ews_values: np.ndarray, ews_times: np.ndarray,
                        baseline_end: float, alpha_r_baseline: float,
                        Tw: float, confidence: float = 0.95,
                        B: Optional[int] = None) -> DetectionResult:
    """
    Test whether variance has significantly increased above baseline.

    Args:
        ews_values: variance time series
        ews_times: corresponding times
        baseline_end: time before which data is baseline
        alpha_r_baseline: restoring rate during baseline
        Tw: window size (set to None if using cross-replica)
        confidence: confidence level (e.g. 0.95)
        B: number of replicas (if using cross-replica estimator)

    Returns:
        DetectionResult
    """
    from scipy.stats import norm
    q = norm.ppf(confidence)

    # Baseline
    bl_mask = ews_times < baseline_end
    if not np.any(bl_mask):
        raise ValueError("No baseline data before baseline_end")
    bl_values = ews_values[bl_mask]
    bl_mean = np.mean(bl_values)

    # Standard errors
    if B is not None:
        # Cross-replica: SE from B
        bl_se = se_cross_replica_variance(bl_mean, B)
    else:
        # Running window: SE from Tw and alpha_r
        bl_se = se_variance(bl_mean, alpha_r_baseline, Tw)

    # Test each time point after baseline
    p_values = np.ones(len(ews_values))
    for i, (t, v) in enumerate(zip(ews_times, ews_values)):
        if t < baseline_end:
            continue
        # Current SE (use variance-proportional scaling)
        if B is not None:
            curr_se = se_cross_replica_variance(v, B)
        else:
            # Approximate current alpha_r from the variance ratio
            alpha_r_curr = alpha_r_baseline * bl_mean / (v + 1e-30)
            curr_se = se_variance(v, alpha_r_curr, Tw)

        total_se = bl_se + curr_se
        if total_se > 0:
            z = (v - bl_mean) / total_se
            p_values[i] = 1.0 - norm.cdf(z)

    # First detection
    detected = np.any(p_values < (1 - confidence))
    det_idx = np.where(p_values < (1 - confidence))[0]
    det_time = ews_times[det_idx[0]] if len(det_idx) > 0 else None

    return DetectionResult(
        detected=detected,
        detection_time=det_time,
        p_values=p_values,
        ews_values=ews_values,
        baseline_value=bl_mean,
        baseline_se=bl_se,
        confidence_level=confidence,
    )


# ═══════════════════════════════════════════════════════════════
# 6. Required Window Size (Ditlevsen Eqs. 7–8)
# ═══════════════════════════════════════════════════════════════

def required_window_variance(alpha_r_0: float, alpha_r_t: float,
                              q: float = 1.96) -> float:
    """
    Minimum window size to detect variance increase at q-confidence level.
    Tw > 2q² · ((α̂(t)/√α̂₀ + α̂₀/√α̂(t)) / (α̂₀ - α̂(t)))²
    [Ditlevsen Eq. 7]
    """
    if alpha_r_0 <= alpha_r_t or alpha_r_t <= 0:
        return np.inf
    num = alpha_r_t / np.sqrt(alpha_r_0) + alpha_r_0 / np.sqrt(alpha_r_t)
    den = alpha_r_0 - alpha_r_t
    return 2 * q ** 2 * (num / den) ** 2


def required_window_autocorrelation(alpha_r_0: float, alpha_r_t: float,
                                     rho_0: float, q: float = 1.96) -> float:
    """
    Minimum window size to detect autocorrelation increase.
    Tw > 2q² · ((√α̂₀ + √α̂(t)) / (α̂₀ - α̂(t)))² · ρ̂₀⁻²
    [Ditlevsen Eq. 8]
    """
    if alpha_r_0 <= alpha_r_t or alpha_r_t <= 0 or rho_0 <= 0:
        return np.inf
    num = np.sqrt(alpha_r_0) + np.sqrt(alpha_r_t)
    den = alpha_r_0 - alpha_r_t
    return 2 * q ** 2 * (num / den) ** 2 / (rho_0 ** 2)


def compute_green_band(alpha_r_0: float, sigma_sq: float, A: float,
                        Tw_fixed: float, q: float = 1.96,
                        n_delta: int = 200):
    """
    Compute the 'green band' — the range of δ where EWS are both
    detectable and not pre-empted by noise-induced tipping.

    Returns:
        delta_grid, Tw_var, Tw_ac, tau_escape
    """
    delta_grid = np.linspace(0.01, 0.25, n_delta)
    Tw_var = np.zeros(n_delta)
    Tw_ac = np.zeros(n_delta)
    tau_escape = np.zeros(n_delta)

    for i, d in enumerate(delta_grid):
        alpha_r = 2 * np.sqrt(A * d)
        rho = np.exp(-alpha_r * 1.0)  # dt = 1

        Tw_var[i] = required_window_variance(alpha_r_0, alpha_r, q)
        Tw_ac[i] = required_window_autocorrelation(alpha_r_0, alpha_r, rho, q)

        # Kramers escape time (Ditlevsen Eq. 10)
        barrier = 4 * (A * d) ** 1.5 / (3 * np.sqrt(A))
        tau_escape[i] = (np.pi / np.sqrt(A * d)) * np.exp(2 * barrier / sigma_sq)

    return delta_grid, Tw_var, Tw_ac, tau_escape


# ═══════════════════════════════════════════════════════════════
# 7. Basin Classification
# ═══════════════════════════════════════════════════════════════

def classify_basin(Q2: np.ndarray, threshold: float) -> np.ndarray:
    """
    Classify each replica at each time as upper or lower basin.

    Args:
        Q2: (n_times, B) array
        threshold: the unstable fixed point q₋* (in absolute units)

    Returns:
        (n_times, B) boolean array — True if in upper basin
    """
    return Q2 > threshold


def basin_mask_at_time(Q2: np.ndarray, t_idx: int, threshold: float,
                        basin: str = "upper") -> np.ndarray:
    """Get mask for replicas in a given basin at time t_idx."""
    if basin == "upper":
        return Q2[t_idx] > threshold
    else:
        return Q2[t_idx] <= threshold


# ═══════════════════════════════════════════════════════════════
# 8. Utility: batch EWS for multiple replicas
# ═══════════════════════════════════════════════════════════════

def per_replica_ews(Q2: np.ndarray, dt: float, Tw_idx: int):
    """
    Compute running-window variance and autocorrelation for each replica.

    Args:
        Q2: (n_times, B) array
        dt: time step
        Tw_idx: half-window in index units

    Returns:
        var_arr: (n_out, B)
        ac_arr: (n_out, B)
    """
    n_t, B = Q2.shape
    n_out = n_t - 2 * Tw_idx
    if n_out <= 0:
        raise ValueError("Window too large for data")

    Q2f = Q2.astype(np.float64)
    var_arr = np.zeros((n_out, B))
    ac_arr = np.zeros((n_out, B))

    for i in range(n_out):
        window = Q2f[i:i + 2 * Tw_idx]  # (2*Tw_idx, B)

        # Detrend per replica
        t_win = np.arange(window.shape[0], dtype=np.float64)
        for b in range(B):
            coeffs = np.polyfit(t_win, window[:, b], 1)
            window[:, b] -= np.polyval(coeffs, t_win)

        # Variance
        var_arr[i] = np.var(window, axis=0, ddof=0)

        # Lag-1 autocorrelation
        m = np.mean(window, axis=0)
        x0 = window[:-1] - m
        x1 = window[1:] - m
        num = np.sum(x0 * x1, axis=0)
        den = np.sum(x0 ** 2, axis=0)
        ac_arr[i] = np.where(den > 1e-30, num / den, 0.0)
        ac_arr[i] = np.clip(ac_arr[i], 1e-6, 1 - 1e-6)

    return var_arr, ac_arr
