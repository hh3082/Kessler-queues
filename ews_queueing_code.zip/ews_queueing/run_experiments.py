"""
run_experiments.py — Full EWS computational plan for the tandem network.

Phase 1: Validate EWS on ramped simulation (α: 0.3 → 0.5)
Phase 2: Calibrate the normal form at equilibrium for various α
Phase 3: Detection power analysis (green band diagram)
Phase 4: Tipping-time estimation (moment + MLE) with bootstrap

Usage:
    python run_experiments.py              # run all phases
    python run_experiments.py --phase 1    # run specific phase
    python run_experiments.py --cpu        # force CPU mode
"""

import os
import sys
import time
import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.ticker as mticker

from tandem_sim import (
    NetworkParams, TandemSimulator, make_alpha_ramp, make_split_init
)
from ews_analysis import (
    compute_running_window_ews, compute_cross_replica_ews,
    compute_cross_replica_autocorrelation, detect_ews_variance,
    required_window_variance, required_window_autocorrelation,
    classify_basin, se_cross_replica_variance, compute_green_band,
)
from tipping_estimator import (
    estimate_tipping_moment, calibrate_normal_form,
    estimate_tipping_mle, TippingEstimate,
)


# ── Plot styling ──
plt.rcParams.update({
    'figure.facecolor': '#0f172a',
    'axes.facecolor': '#1e293b',
    'text.color': '#e2e8f0',
    'axes.labelcolor': '#cbd5e1',
    'xtick.color': '#94a3b8',
    'ytick.color': '#94a3b8',
    'axes.edgecolor': '#334155',
    'grid.color': '#334155',
    'grid.alpha': 0.5,
    'font.family': 'sans-serif',
    'font.size': 11,
    'axes.titlesize': 13,
    'axes.titleweight': 'bold',
})
COLORS = {
    'blue': '#38bdf8', 'purple': '#a78bfa', 'orange': '#fb923c',
    'green': '#34d399', 'red': '#f87171', 'yellow': '#fbbf24',
    'cyan': '#22d3ee', 'pink': '#f472b6', 'gray': '#64748b',
}

OUT_DIR = "results"
os.makedirs(OUT_DIR, exist_ok=True)


# ═══════════════════════════════════════════════════════════════
# Phase 1: Ramped Simulation — Validate EWS
# ═══════════════════════════════════════════════════════════════

def phase1(n=1000, B=4096, T=800, tau_r=500, alpha_0=0.3, alpha_c=0.5,
           t0=100, dt_record=1.0, Tw=50):
    """
    Simulate with α ramping from α₀ to αc. Compute cross-replica and
    running-window EWS. Verify variance divergence and autocorrelation → 1.
    """
    print("\n" + "="*70)
    print("PHASE 1: Ramped Simulation — Validate Early-Warning Signals")
    print("="*70)

    params = NetworkParams(n=n, theta=0.5, gamma=1.0, alpha=alpha_0, epsilon=0.01)
    print(f"  n={n}, θ={params.theta}, γ={params.gamma}, α₀={alpha_0}")
    print(f"  n₂ʰⁱ={params.n2_hi:.1f}, K={params.K:.1f}, δ₀={params.delta:.4f}")
    print(f"  Ramping: α {alpha_0} → {alpha_c} over t=[{t0}, {t0+tau_r}]")
    print(f"  Replicas: B={B}, T={T}, dt_record={dt_record}")

    # Ramping schedule
    schedule = make_alpha_ramp(alpha_0, alpha_c, t0, tau_r)

    # All replicas start in upper basin
    Q2_init = int(0.9 * params.n2_hi)

    sim = TandemSimulator(params, B=B, dt_sim=0.005, seed=42)
    print("  Simulating...", flush=True)
    t_start = time.time()
    result = sim.simulate(T=T, dt_record=dt_record, Q2_init=Q2_init,
                          alpha_schedule=schedule, burnin_frac=0.0)
    elapsed = time.time() - t_start
    print(f"  Done in {elapsed:.1f}s. Shape: Q2={result['Q2'].shape}")

    times = result['times']
    Q2 = result['Q2']
    alpha_t = result['alpha_t']

    # ── Cross-replica EWS ──
    print("  Computing cross-replica EWS...")
    cr_ews = compute_cross_replica_ews(Q2, times)
    cr_ac = compute_cross_replica_autocorrelation(Q2)

    # ── Running-window EWS on ensemble mean ──
    print(f"  Computing running-window EWS (Tw={Tw})...")
    Q2_mean = np.mean(Q2.astype(np.float64), axis=1)
    rw_ews = compute_running_window_ews(Q2_mean, times, Tw=Tw, dt=dt_record)

    # ── Detection test ──
    print("  Running detection test (variance)...")
    det = detect_ews_variance(
        cr_ews.variance, cr_ews.times,
        baseline_end=t0,
        alpha_r_baseline=2 * np.sqrt(0.25 - alpha_0 ** 2),  # rough
        Tw=None, B=B, confidence=0.95,
    )
    if det.detected:
        print(f"  ✓ EWS DETECTED at t = {det.detection_time:.1f}")
    else:
        print(f"  ✗ No significant EWS detected at 95% level")

    # ── Plot ──
    fig = plt.figure(figsize=(16, 14))
    gs = GridSpec(3, 2, hspace=0.35, wspace=0.3,
                  left=0.08, right=0.95, top=0.94, bottom=0.06)

    # (a) Sample trajectories
    ax1 = fig.add_subplot(gs[0, 0])
    for b in range(min(20, B)):
        ax1.plot(times, Q2[:, b], alpha=0.15, color=COLORS['blue'], lw=0.5)
    ax1.plot(times, Q2_mean, color=COLORS['cyan'], lw=1.5, label='ensemble mean')
    ax1.axvline(t0, color=COLORS['yellow'], ls='--', lw=1, alpha=0.7, label=f't₀={t0}')
    ax1.axvline(t0 + tau_r, color=COLORS['red'], ls='--', lw=1, alpha=0.7, label=f'tc={t0+tau_r}')
    ax1.set_xlabel('Time')
    ax1.set_ylabel('Q₂')
    ax1.set_title('(a) Station 2 trajectories (upper basin)')
    ax1.legend(fontsize=9)
    ax1.grid(True)

    # (b) Alpha ramp
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.plot(times, alpha_t, color=COLORS['purple'], lw=2)
    ax2.axhline(0.5, color=COLORS['red'], ls='--', lw=1, alpha=0.7, label='αc = 0.5')
    ax2.axvline(t0, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5)
    delta_t = 0.25 - alpha_t ** 2
    ax2b = ax2.twinx()
    ax2b.plot(times, delta_t, color=COLORS['orange'], lw=1.5, ls=':')
    ax2b.set_ylabel('δ(t) = ¼ − α²', color=COLORS['orange'])
    ax2b.tick_params(axis='y', labelcolor=COLORS['orange'])
    ax2.set_xlabel('Time')
    ax2.set_ylabel('α(t)')
    ax2.set_title('(b) Control parameter ramp')
    ax2.legend(fontsize=9)
    ax2.grid(True)

    # (c) Cross-replica variance
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.plot(cr_ews.times, cr_ews.variance, color=COLORS['orange'], lw=1.5,
             label='cross-replica var(Q₂)')
    # Baseline band
    bl_var = np.mean(cr_ews.variance[cr_ews.times < t0])
    bl_se = se_cross_replica_variance(bl_var, B)
    ax3.axhline(bl_var, color=COLORS['gray'], ls='-', lw=1, alpha=0.5)
    ax3.fill_between(cr_ews.times,
                     bl_var - 2 * bl_se, bl_var + 2 * bl_se,
                     color=COLORS['purple'], alpha=0.15, label='baseline ± 2 SE')
    ax3.axvline(t0, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5)
    if det.detected:
        ax3.axvline(det.detection_time, color=COLORS['green'], ls='-', lw=2,
                    alpha=0.7, label=f'detection at t={det.detection_time:.0f}')
    ax3.set_xlabel('Time')
    ax3.set_ylabel('Variance')
    ax3.set_title('(c) Cross-replica variance (EWS #1)')
    ax3.legend(fontsize=9)
    ax3.grid(True)

    # (d) Cross-replica autocorrelation
    ax4 = fig.add_subplot(gs[1, 1])
    # Smooth the autocorrelation
    kernel = np.ones(20) / 20
    ac_smooth = np.convolve(cr_ac, kernel, mode='same')
    ax4.plot(times, ac_smooth, color=COLORS['cyan'], lw=1.5,
             label='cross-replica AC(Q₂)')
    ax4.axhline(1.0, color=COLORS['red'], ls=':', lw=1, alpha=0.5)
    ax4.axvline(t0, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5)
    ax4.set_xlabel('Time')
    ax4.set_ylabel('Lag-1 Autocorrelation')
    ax4.set_title('(d) Cross-replica autocorrelation (EWS #2)')
    ax4.legend(fontsize=9)
    ax4.set_ylim(-0.1, 1.1)
    ax4.grid(True)

    # (e) Running-window α_restore
    ax5 = fig.add_subplot(gs[2, 0])
    ax5.plot(rw_ews.times, rw_ews.alpha_restore, color=COLORS['green'], lw=1.5,
             label='α_restore(t)')
    ax5.axhline(0, color=COLORS['red'], ls='--', lw=1, alpha=0.7)
    ax5.axvline(t0, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5)
    ax5.set_xlabel('Time')
    ax5.set_ylabel('α_restore (restoring rate)')
    ax5.set_title('(e) Restoring rate → 0 (critical slowing down)')
    ax5.legend(fontsize=9)
    ax5.grid(True)

    # (f) A·δ(t) — should decrease linearly
    ax6 = fig.add_subplot(gs[2, 1])
    ax6.plot(rw_ews.times, rw_ews.A_delta, color=COLORS['pink'], lw=1.5,
             label='Aδ(t) = α_restore²/4')
    # Fit line for tipping time estimate
    mask = rw_ews.times > t0
    if np.any(mask):
        est = estimate_tipping_moment(rw_ews.A_delta[mask], rw_ews.times[mask])
        if np.isfinite(est.t_c):
            fit_line = est.params['slope'] * rw_ews.times[mask] + est.params['intercept']
            ax6.plot(rw_ews.times[mask], fit_line, color=COLORS['red'], ls='--', lw=2,
                     label=f'linear fit → tc = {est.t_c:.0f}')
            ax6.axvline(est.t_c, color=COLORS['red'], ls=':', lw=1.5, alpha=0.7)
            print(f"\n  Moment estimator: t_c = {est.t_c:.1f}")
            print(f"    95% CI: [{est.ci_95[0]:.1f}, {est.ci_95[1]:.1f}]")
            print(f"    True t_c: {t0 + tau_r}")
    ax6.axhline(0, color=COLORS['red'], ls='--', lw=1, alpha=0.5)
    ax6.axvline(t0, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5)
    ax6.set_xlabel('Time')
    ax6.set_ylabel('Aδ(t)')
    ax6.set_title('(f) Tipping-time estimate (Aδ → 0 at tc)')
    ax6.legend(fontsize=9)
    ax6.grid(True)

    fig.suptitle(f'Phase 1: EWS Validation — n={n}, B={B}, α: {alpha_0}→{alpha_c}, τ_r={tau_r}',
                 fontsize=15, fontweight='bold', color='white')
    fig.savefig(os.path.join(OUT_DIR, 'phase1_ews_validation.png'), dpi=180)
    print(f"  Saved: {OUT_DIR}/phase1_ews_validation.png")
    plt.close()

    return result, cr_ews, rw_ews


# ═══════════════════════════════════════════════════════════════
# Phase 2: Normal-Form Calibration
# ═══════════════════════════════════════════════════════════════

def phase2(n=1000, B=2048, T=300, dt_record=1.0, Tw=50):
    """
    Run equilibrium simulations at various α values.
    Measure variance and autocorrelation.
    Verify δ^{-1/2} scaling and fit the normal-form parameters.
    """
    print("\n" + "="*70)
    print("PHASE 2: Normal-Form Calibration")
    print("="*70)

    alpha_values = np.array([0.15, 0.20, 0.25, 0.30, 0.35, 0.38, 0.40, 0.42,
                             0.44, 0.46, 0.48])

    var_values = np.zeros(len(alpha_values))
    ac_values = np.zeros(len(alpha_values))
    mean_values = np.zeros(len(alpha_values))

    for i, alpha in enumerate(alpha_values):
        print(f"  α = {alpha:.2f} (δ = {0.25 - alpha**2:.4f}) ...", end=" ", flush=True)

        params = NetworkParams(n=n, theta=0.5, gamma=1.0, alpha=alpha, epsilon=0.01)
        fp = params.fixed_points()

        if not fp['exists']:
            print("no bistability, skipping")
            var_values[i] = np.nan
            ac_values[i] = np.nan
            mean_values[i] = np.nan
            continue

        Q2_init = int(fp['q_plus'] * params.n2_hi)
        sim = TandemSimulator(params, B=B, dt_sim=0.005, seed=i * 100)
        result = sim.simulate(T=T, dt_record=dt_record, Q2_init=Q2_init,
                              burnin_frac=0.2)

        Q2 = result['Q2']
        times = result['times']

        # Basin-aware filtering: only use replicas still in upper basin
        # Threshold: unstable fixed point q₋* in absolute units
        threshold = fp['q_minus'] * params.n2_hi
        half = len(times) // 2
        Q2_late = Q2[half:]

        # At each time, identify upper-basin replicas
        upper_mask_final = Q2_late[-1] > threshold
        n_upper = np.sum(upper_mask_final)

        if n_upper < 20:
            print(f"too few upper-basin replicas ({n_upper}/{B}), skipping")
            var_values[i] = np.nan
            ac_values[i] = np.nan
            mean_values[i] = np.nan
            continue

        # Compute EWS only from upper-basin replicas
        cr = compute_cross_replica_ews(Q2_late, times[half:],
                                       basin_mask=upper_mask_final)

        var_values[i] = np.mean(cr.variance)
        mean_values[i] = np.mean(cr.mean)

        # Autocorrelation from cross-replica (upper basin only)
        ac = compute_cross_replica_autocorrelation(Q2_late,
                                                    basin_mask=upper_mask_final)
        ac_values[i] = np.mean(ac[1:])  # skip t=0

        print(f"var={var_values[i]:.1f}, AC={ac_values[i]:.3f}, "
              f"mean={mean_values[i]:.1f}, upper={n_upper}/{B}")

    # Calibrate normal form
    valid = np.isfinite(var_values)
    if np.sum(valid) > 3:
        cal = calibrate_normal_form(
            alpha_values[valid], var_values[valid],
            ac_values[valid], mean_values[valid], dt=dt_record
        )
        print(f"\n  Normal-form calibration:")
        print(f"    A = {cal['A']:.4f}")
        print(f"    m = {cal['m']:.1f}")
        print(f"    σ = {cal['sigma']:.3f}")
        print(f"    Variance scaling exponent: {cal['scaling_exponent']:.3f} (theory: -0.5)")
        print(f"    R² for α_restore² vs δ: {cal['r_squared']:.4f}")
    else:
        cal = None

    # ── Plot ──
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # Work only with valid data
    av = alpha_values[valid]
    dv = 0.25 - av ** 2
    vv = var_values[valid]
    acv = ac_values[valid]
    mv = mean_values[valid]

    # (a) Variance vs δ (log-log)
    ax = axes[0, 0]
    ax.loglog(dv, vv, 'o-', color=COLORS['orange'], ms=6, lw=1.5, label='measured')
    if cal and np.isfinite(cal['scaling_exponent']):
        d_fit = np.linspace(dv.min(), dv.max(), 100)
        a_fit = np.exp(np.polyval(
            np.polyfit(np.log(dv), np.log(vv), 1), np.log(d_fit)
        ))
        ax.loglog(d_fit, a_fit, '--', color=COLORS['red'], lw=1.5,
                  label=f'fit: exponent = {cal["scaling_exponent"]:.2f}')
    ax.set_xlabel('δ = ¼ − α²')
    ax.set_ylabel('Variance of Q₂')
    ax.set_title('(a) Variance scaling: γ² ~ δ⁻¹ᐟ²')
    ax.legend(fontsize=9)
    ax.grid(True, which='both')

    # (b) α_restore² vs δ (should be linear)
    ax = axes[0, 1]
    if cal:
        ar = cal['alpha_restore_values']
        ax.plot(dv, ar ** 2, 'o-', color=COLORS['green'], ms=6, lw=1.5,
                label='measured α_r²')
        d_fit = np.linspace(0, dv.max(), 100)
        ax.plot(d_fit, 4 * cal['A'] * d_fit, '--', color=COLORS['red'], lw=1.5,
                label=f'fit: 4Aδ, A={cal["A"]:.4f}')
    ax.set_xlabel('δ = ¼ − α²')
    ax.set_ylabel('α_restore²')
    ax.set_title('(b) α_restore² = 4Aδ (linear in δ)')
    ax.legend(fontsize=9)
    ax.grid(True)

    # (c) Autocorrelation vs δ
    ax = axes[1, 0]
    ax.plot(dv, acv, 'o-', color=COLORS['cyan'], ms=6, lw=1.5, label='measured')
    ax.axhline(1.0, color=COLORS['red'], ls=':', lw=1, alpha=0.5)
    ax.set_xlabel('δ = ¼ − α²')
    ax.set_ylabel('Lag-1 autocorrelation')
    ax.set_title('(c) Autocorrelation ρ → 1 as δ → 0')
    ax.legend(fontsize=9)
    ax.grid(True)

    # (d) Mean Q₂ vs √δ (should be linear: μ = m + √(δ/A))
    ax = axes[1, 1]
    sqrt_d = np.sqrt(dv)
    ax.plot(sqrt_d, mv, 'o-', color=COLORS['purple'], ms=6, lw=1.5,
            label='measured mean Q₂')
    if cal and cal['A'] > 0:
        x_fit = np.linspace(0, sqrt_d.max(), 100)
        y_fit = cal['m'] + x_fit / np.sqrt(cal['A'])
        ax.plot(x_fit, y_fit, '--', color=COLORS['red'], lw=1.5,
                label=f'fit: m + √(δ/A)')
    ax.set_xlabel('√δ')
    ax.set_ylabel('Mean Q₂')
    ax.set_title('(d) Mean: μ = m + √(δ/A) (square-root law)')
    ax.legend(fontsize=9)
    ax.grid(True)

    fig.suptitle(f'Phase 2: Normal-Form Calibration — n={n}',
                 fontsize=15, fontweight='bold', color='white')
    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(os.path.join(OUT_DIR, 'phase2_normal_form.png'), dpi=180)
    print(f"  Saved: {OUT_DIR}/phase2_normal_form.png")
    plt.close()

    return cal


# ═══════════════════════════════════════════════════════════════
# Phase 3: Detection Power Analysis (Green Band)
# ═══════════════════════════════════════════════════════════════

def phase3(cal: dict, n=1000, alpha_0=0.3, Tw_fixed=50):
    """
    Compute the 'green band' diagram: the range of δ where EWS are
    detectable but noise-induced tipping hasn't occurred.

    Analog of Ditlevsen Fig. 4a.
    """
    print("\n" + "="*70)
    print("PHASE 3: Detection Power Analysis (Green Band)")
    print("="*70)

    if cal is None or not np.isfinite(cal.get('A', np.nan)):
        print("  Skipping: normal-form calibration not available")
        return

    A = cal['A']
    sigma = cal['sigma']
    sigma_sq = sigma ** 2

    delta_0 = 0.25 - alpha_0 ** 2
    alpha_r_0 = 2 * np.sqrt(A * delta_0)
    rho_0 = np.exp(-alpha_r_0 * 1.0)

    delta_grid, Tw_var, Tw_ac, tau_escape = compute_green_band(
        alpha_r_0, sigma_sq, A, Tw_fixed, q=1.96
    )

    # Convert delta to alpha for easier interpretation
    alpha_grid = np.sqrt(0.25 - delta_grid)

    # Green band boundaries
    # Left: where Tw_var <= Tw_fixed
    detect_ok = Tw_var <= Tw_fixed
    # Right: where tau_escape <= Tw_fixed
    escape_ok = tau_escape > Tw_fixed

    green = detect_ok & escape_ok

    print(f"  A = {A:.4f}, σ = {sigma:.3f}")
    print(f"  Baseline: α₀={alpha_0}, δ₀={delta_0:.4f}, α_r₀={alpha_r_0:.3f}")

    if np.any(green):
        d_green = delta_grid[green]
        print(f"  Green band: δ ∈ [{d_green.min():.4f}, {d_green.max():.4f}]")
        a_green = alpha_grid[green]
        print(f"              α ∈ [{a_green.min():.3f}, {a_green.max():.3f}]")
    else:
        print("  No green band found (EWS not usable for these parameters)")

    # ── Plot ──
    fig, ax = plt.subplots(1, 1, figsize=(12, 7))

    ax.semilogy(delta_grid, Tw_var, color=COLORS['orange'], lw=2.5,
                label='Tw needed (variance)')
    ax.semilogy(delta_grid, Tw_ac, color=COLORS['cyan'], lw=2.5,
                label='Tw needed (autocorrelation)')
    ax.semilogy(delta_grid, tau_escape, color=COLORS['blue'], lw=2.5,
                label='τ_escape (Kramers)')
    ax.axhline(Tw_fixed, color=COLORS['gray'], ls='-.', lw=1.5,
               label=f'Tw = {Tw_fixed}')

    # Green band shading
    if np.any(green):
        d_min, d_max = delta_grid[green].min(), delta_grid[green].max()
        ax.axvspan(d_min, d_max, color=COLORS['green'], alpha=0.12,
                   label='actionable EWS range')

    ax.set_xlabel('δ = ¼ − α²  (→ 0 at bifurcation)')
    ax.set_ylabel('Time scale')
    ax.set_title('Detection Power: Green Band Diagram (cf. Ditlevsen Fig. 4a)')
    ax.legend(fontsize=10, loc='upper right')
    ax.set_ylim(1, 1e8)
    ax.set_xlim(0, 0.25)
    ax.grid(True, which='both')

    # Top axis: alpha
    ax_top = ax.twiny()
    alpha_ticks = [0.0, 0.1, 0.2, 0.3, 0.4, 0.45, 0.49]
    delta_ticks = [0.25 - a**2 for a in alpha_ticks]
    ax_top.set_xlim(ax.get_xlim())
    ax_top.set_xticks(delta_ticks)
    ax_top.set_xticklabels([f'{a:.2f}' for a in alpha_ticks])
    ax_top.set_xlabel('α (routing parameter)', color=COLORS['purple'])
    ax_top.tick_params(axis='x', labelcolor=COLORS['purple'])

    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, 'phase3_green_band.png'), dpi=180)
    print(f"  Saved: {OUT_DIR}/phase3_green_band.png")
    plt.close()


# ═══════════════════════════════════════════════════════════════
# Phase 4: Tipping-Time Estimation
# ═══════════════════════════════════════════════════════════════

def phase4(n=1000, B=4096, T=800, tau_r=500, alpha_0=0.3, alpha_c=0.5,
           t0=100, dt_record=1.0, Tw=50, n_bootstrap=200):
    """
    Estimate the tipping time from simulated data using:
      1. Moment-based estimator
      2. MLE with Strang splitting
      3. Bootstrap confidence intervals
    """
    print("\n" + "="*70)
    print("PHASE 4: Tipping-Time Estimation")
    print("="*70)

    params = NetworkParams(n=n, theta=0.5, gamma=1.0, alpha=alpha_0, epsilon=0.01)
    true_tc = t0 + tau_r
    print(f"  True tipping time: tc = {true_tc}")

    # Simulate
    schedule = make_alpha_ramp(alpha_0, alpha_c, t0, tau_r)
    Q2_init = int(0.9 * params.n2_hi)
    sim = TandemSimulator(params, B=B, dt_sim=0.005, seed=123)
    print("  Simulating...", flush=True)
    result = sim.simulate(T=T, dt_record=dt_record, Q2_init=Q2_init,
                          alpha_schedule=schedule)

    times = result['times']
    Q2 = result['Q2']

    # Use only first 80% of data (simulate not knowing tc)
    cutoff_idx = int(0.80 * len(times))
    times_obs = times[:cutoff_idx]
    Q2_obs = Q2[:cutoff_idx]

    print(f"  Using data up to t = {times_obs[-1]:.0f} (true tc = {true_tc})")

    # ── Method 1: Moment estimator from cross-replica variance ──
    cr_ews = compute_cross_replica_ews(Q2_obs, times_obs)
    Q2_mean = np.mean(Q2_obs.astype(np.float64), axis=1)
    rw_ews = compute_running_window_ews(Q2_mean, times_obs, Tw=Tw, dt=dt_record)

    mask_after = rw_ews.times > t0
    if np.any(mask_after):
        moment_est = estimate_tipping_moment(
            rw_ews.A_delta[mask_after], rw_ews.times[mask_after]
        )
        print(f"\n  Method 1 — Moment estimator:")
        print(f"    t_c = {moment_est.t_c:.1f}")
        print(f"    95% CI: [{moment_est.ci_95[0]:.1f}, {moment_est.ci_95[1]:.1f}]")
        print(f"    Error: {moment_est.t_c - true_tc:.1f}")
    else:
        moment_est = TippingEstimate(
            method="moment", t_c=np.nan, t_0=t0, tau_r=np.nan,
            alpha_0=alpha_0, ci_95=(np.nan, np.nan), ci_66=(np.nan, np.nan),
            params={}
        )

    # ── Method 2: MLE (on ensemble-mean trajectory) ──
    print("\n  Method 2 — MLE (Strang splitting)...")
    params_dict = {
        'Lambda': params.Lambda, 'gamma': params.gamma,
        'epsilon': params.epsilon, 'n2hi': params.n2_hi,
    }
    # Subsample for MLE (every 5 steps for speed)
    step = 5
    mle_est = estimate_tipping_mle(
        Q2_mean[::step], times_obs[::step],
        params_dict, t0_fixed=t0, alpha_0=alpha_0
    )
    print(f"    t_c = {mle_est.t_c:.1f}")
    print(f"    Error: {mle_est.t_c - true_tc:.1f}")

    # ── Bootstrap ──
    print(f"\n  Bootstrap ({n_bootstrap} replications)...")
    tc_bootstrap = []
    for b in range(n_bootstrap):
        if b % 50 == 0:
            print(f"    bootstrap {b}/{n_bootstrap}...", flush=True)
        # Resample replicas with replacement
        idx = np.random.randint(0, B, size=B)
        Q2_boot = Q2_obs[:, idx]
        Q2_boot_mean = np.mean(Q2_boot.astype(np.float64), axis=1)
        rw_boot = compute_running_window_ews(Q2_boot_mean, times_obs, Tw=Tw, dt=dt_record)
        mask_b = rw_boot.times > t0
        if np.any(mask_b):
            est_b = estimate_tipping_moment(rw_boot.A_delta[mask_b], rw_boot.times[mask_b])
            if np.isfinite(est_b.t_c) and est_b.t_c > t0 and est_b.t_c < 3 * true_tc:
                tc_bootstrap.append(est_b.t_c)

    tc_bootstrap = np.array(tc_bootstrap)
    if len(tc_bootstrap) > 10:
        ci_95 = (np.percentile(tc_bootstrap, 2.5), np.percentile(tc_bootstrap, 97.5))
        ci_66 = (np.percentile(tc_bootstrap, 17), np.percentile(tc_bootstrap, 83))
        print(f"\n  Bootstrap results ({len(tc_bootstrap)} successful):")
        print(f"    Mean t_c: {np.mean(tc_bootstrap):.1f}")
        print(f"    95% CI: [{ci_95[0]:.1f}, {ci_95[1]:.1f}]")
        print(f"    66% CI: [{ci_66[0]:.1f}, {ci_66[1]:.1f}]")
        print(f"    True t_c: {true_tc}")
    else:
        ci_95 = (np.nan, np.nan)
        ci_66 = (np.nan, np.nan)
        print("  Bootstrap failed (too few successful estimates)")

    # ── Plot ──
    fig = plt.figure(figsize=(14, 10))
    gs = GridSpec(2, 2, hspace=0.35, wspace=0.3)

    # (a) Aδ(t) with linear fit
    ax = fig.add_subplot(gs[0, 0])
    if np.any(mask_after):
        ax.plot(rw_ews.times[mask_after], rw_ews.A_delta[mask_after],
                color=COLORS['pink'], lw=1.5, label='Aδ(t)')
        if np.isfinite(moment_est.t_c):
            t_plot = rw_ews.times[mask_after]
            fit = moment_est.params['slope'] * t_plot + moment_est.params['intercept']
            ax.plot(t_plot, fit, '--', color=COLORS['red'], lw=2,
                    label=f'fit → tc = {moment_est.t_c:.0f}')
    ax.axhline(0, color=COLORS['gray'], ls=':', lw=1)
    ax.axvline(true_tc, color=COLORS['green'], ls='--', lw=2, alpha=0.7,
               label=f'true tc = {true_tc}')
    ax.set_xlabel('Time')
    ax.set_ylabel('Aδ(t) = α_restore²/4')
    ax.set_title('(a) Moment Estimator')
    ax.legend(fontsize=9)
    ax.grid(True)

    # (b) Bootstrap histogram
    ax = fig.add_subplot(gs[0, 1])
    if len(tc_bootstrap) > 10:
        ax.hist(tc_bootstrap, bins=30, color=COLORS['purple'], alpha=0.7,
                edgecolor=COLORS['blue'], density=True)
        ax.axvline(true_tc, color=COLORS['green'], ls='--', lw=2.5,
                   label=f'true tc = {true_tc}')
        ax.axvline(np.mean(tc_bootstrap), color=COLORS['orange'], ls='-', lw=2,
                   label=f'mean = {np.mean(tc_bootstrap):.0f}')
        ax.axvspan(ci_95[0], ci_95[1], color=COLORS['yellow'], alpha=0.1,
                   label=f'95% CI')
    ax.set_xlabel('Estimated tipping time tc')
    ax.set_ylabel('Density')
    ax.set_title('(b) Bootstrap Distribution of t̂c')
    ax.legend(fontsize=9)
    ax.grid(True)

    # (c) Cross-replica variance with detection
    ax = fig.add_subplot(gs[1, 0])
    ax.plot(cr_ews.times, cr_ews.variance, color=COLORS['orange'], lw=1, alpha=0.8)
    # Rolling average
    kernel = np.ones(20) / 20
    var_smooth = np.convolve(cr_ews.variance, kernel, mode='same')
    ax.plot(cr_ews.times, var_smooth, color=COLORS['orange'], lw=2.5,
            label='variance (smoothed)')
    ax.axvline(t0, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5, label='t₀')
    ax.axvline(true_tc, color=COLORS['green'], ls='--', lw=2, alpha=0.7, label='true tc')
    ax.set_xlabel('Time')
    ax.set_ylabel('Cross-replica variance')
    ax.set_title('(c) Variance Divergence')
    ax.legend(fontsize=9)
    ax.grid(True)

    # (d) Differential diagnostic: upper vs lower basin
    ax = fig.add_subplot(gs[1, 1])
    # Check both basins from a split-init run
    ax.text(0.5, 0.5, '(d) Reserved for\ndifferential diagnostic\n(upper vs lower basin)',
            transform=ax.transAxes, ha='center', va='center',
            fontsize=12, color=COLORS['gray'])
    ax.set_title('(d) Basin Comparison (run with split init)')
    ax.grid(True)

    fig.suptitle(f'Phase 4: Tipping-Time Estimation — true tc = {true_tc}',
                 fontsize=15, fontweight='bold', color='white')
    fig.savefig(os.path.join(OUT_DIR, 'phase4_tipping_estimate.png'), dpi=180)
    print(f"\n  Saved: {OUT_DIR}/phase4_tipping_estimate.png")
    plt.close()

    return moment_est, mle_est, tc_bootstrap


# ═══════════════════════════════════════════════════════════════
# Phase 5: Debris-Trap Scenario (Reverse Direction)
# ═══════════════════════════════════════════════════════════════

def phase5(n=1000, B=4096, T=1200, tau_r=600, alpha_start=0.55,
           alpha_end=0.30, t0=100, dt_record=1.0):
    """
    The debris-trap scenario: α ramps DOWNWARD from monostable safety
    (α > 0.5) into the bistable regime (α < 0.5).

    Physics:
      - For α > 0.5: only the low state exists. Station 2 is nearly
        empty. Safe operation — debris drains harmlessly.
      - At α = 0.5: saddle-node bifurcation CREATES the upper attractor.
        The debris trap springs into existence.
      - For α < 0.5: two stable states. The upper one (runaway debris)
        can capture the system once noise pushes Q₂ above the unstable
        threshold q₋*.
      - As α continues to decrease, the barrier from low → high SHRINKS,
        making capture increasingly likely.

    Key difference from Phases 1–4 (Ditlevsen analog):
      The LOW state does NOT undergo critical slowing down — its
      restoring rate f'(0) ≈ −γ is independent of α. So variance
      and autocorrelation of Q₂ near zero do NOT diverge.

    Instead, the EWS for capture are:
      1. Fraction of replicas captured (the direct observable)
      2. Upper-tail excursion statistics (flickering)
      3. Cross-replica variance spike (bimodality onset)
      4. Skewness increase (asymmetric upward excursions)
      5. Kramers escape time from low basin (theoretical prediction)

    We also compare with the Ditlevsen framework applied to replicas
    that HAVE been captured (monitoring collapse of the high state
    if α were to reverse — i.e., checking whether the standard EWS
    would work from the upper basin's perspective).
    """
    print("\n" + "="*70)
    print("PHASE 5: Debris-Trap Scenario — Capture into Runaway State")
    print("="*70)

    params = NetworkParams(n=n, theta=0.5, gamma=1.0, alpha=alpha_start, epsilon=0.01)
    print(f"  n={n}, θ={params.theta}, γ={params.gamma}")
    print(f"  Ramping: α {alpha_start} → {alpha_end} over t=[{t0}, {t0+tau_r}]")
    print(f"  Bifurcation at α=0.5 crossed at t = {t0 + tau_r * (alpha_start - 0.5) / (alpha_start - alpha_end):.0f}")
    print(f"  Replicas: B={B}, all starting in LOW state (Q₂ ≈ 0)")

    # Time when α crosses 0.5
    t_bif = t0 + tau_r * (alpha_start - 0.5) / (alpha_start - alpha_end)

    # Ramping schedule: α DECREASES
    def alpha_schedule(t):
        if t < t0:
            return alpha_start
        else:
            return max(alpha_end, alpha_start - (alpha_start - alpha_end) * (t - t0) / tau_r)

    # All replicas start in the LOW state
    Q2_init = 0

    sim = TandemSimulator(params, B=B, dt_sim=0.005, seed=777)
    print("  Simulating...", flush=True)
    t_start = time.time()
    result = sim.simulate(T=T, dt_record=dt_record, Q2_init=Q2_init,
                          alpha_schedule=alpha_schedule, burnin_frac=0.0)
    elapsed = time.time() - t_start
    print(f"  Done in {elapsed:.1f}s. Shape: Q2={result['Q2'].shape}")

    times = result['times']
    Q2 = result['Q2']
    alpha_t = result['alpha_t']

    # ── Compute α-dependent threshold and fixed points over time ──
    n2hi_t = params.Lambda / params.gamma  # approximately constant
    threshold_t = np.zeros(len(times))
    q_plus_t = np.zeros(len(times))
    barrier_exists = np.zeros(len(times), dtype=bool)

    for i, a in enumerate(alpha_t):
        disc = 1 - 4 * a ** 2
        if disc > 0:
            sq = np.sqrt(disc)
            threshold_t[i] = (1 - sq) / 2 * n2hi_t  # q₋* in absolute units
            q_plus_t[i] = (1 + sq) / 2 * n2hi_t      # q₊* in absolute units
            barrier_exists[i] = True
        else:
            threshold_t[i] = np.nan
            q_plus_t[i] = np.nan

    # ── EWS #1: Fraction of replicas captured ──
    # A replica is "captured" if Q₂ > threshold (unstable fixed point)
    frac_captured = np.zeros(len(times))
    for i in range(len(times)):
        if barrier_exists[i]:
            frac_captured[i] = np.mean(Q2[i] > threshold_t[i])
        else:
            frac_captured[i] = 0.0

    # First capture time (any replica)
    any_captured = np.where(frac_captured > 0)[0]
    if len(any_captured) > 0:
        t_first_capture = times[any_captured[0]]
        print(f"  First capture at t = {t_first_capture:.1f} "
              f"(α = {alpha_t[any_captured[0]]:.3f})")
    else:
        t_first_capture = None
        print("  No captures observed")

    # 50% capture time
    half_captured = np.where(frac_captured > 0.5)[0]
    if len(half_captured) > 0:
        t_half = times[half_captured[0]]
        print(f"  50% captured at t = {t_half:.1f} "
              f"(α = {alpha_t[half_captured[0]]:.3f})")

    # ── EWS #2: Cross-replica variance (bimodality onset) ──
    cr_ews = compute_cross_replica_ews(Q2, times)

    # ── EWS #3: Upper-tail statistics (flickering) ──
    Q2f = Q2.astype(np.float64)
    # 95th percentile across replicas at each time
    q95 = np.percentile(Q2f, 95, axis=1)
    q99 = np.percentile(Q2f, 99, axis=1)
    q_max = np.max(Q2f, axis=1)

    # ── EWS #4: Skewness (positive skew = upward excursions) ──
    # Already in cr_ews.skewness

    # ── EWS #5: Ditlevsen-style analysis on captured replicas ──
    # For replicas that HAVE been captured and are in the upper basin,
    # compute variance/autocorrelation to check if Ditlevsen EWS work
    # from the upper basin's perspective
    ditlevsen_times = []
    ditlevsen_var = []
    ditlevsen_ac = []
    ditlevsen_alpha_r = []

    Tw_idx = 25  # half-window of 25 time steps
    for i in range(Tw_idx, len(times) - Tw_idx):
        if not barrier_exists[i]:
            continue
        # Find replicas in upper basin at window midpoint
        upper_mask = Q2[i] > threshold_t[i]
        n_upper = np.sum(upper_mask)
        if n_upper < 30:
            continue

        # Compute variance of upper-basin replicas within window
        window = Q2f[i - Tw_idx:i + Tw_idx, upper_mask]
        # Check they stay in upper basin throughout window
        stays_upper = np.all(window > threshold_t[i] * 0.5, axis=0)
        if np.sum(stays_upper) < 20:
            continue

        window_stable = window[:, stays_upper]
        var = np.mean(np.var(window_stable, axis=0))
        # Autocorrelation per replica, then average
        acs = []
        for b in range(window_stable.shape[1]):
            ts = window_stable[:, b]
            ts_c = ts - np.mean(ts)
            if np.sum(ts_c ** 2) > 0:
                ac = np.sum(ts_c[:-1] * ts_c[1:]) / np.sum(ts_c ** 2)
                acs.append(np.clip(ac, 0.01, 0.999))
        if len(acs) > 5:
            ac_mean = np.mean(acs)
            alpha_r = -np.log(ac_mean) / dt_record
            ditlevsen_times.append(times[i])
            ditlevsen_var.append(var)
            ditlevsen_ac.append(ac_mean)
            ditlevsen_alpha_r.append(alpha_r)

    ditlevsen_times = np.array(ditlevsen_times)
    ditlevsen_var = np.array(ditlevsen_var)
    ditlevsen_ac = np.array(ditlevsen_ac)
    ditlevsen_alpha_r = np.array(ditlevsen_alpha_r)

    if len(ditlevsen_times) > 0:
        print(f"\n  Ditlevsen EWS from upper basin ({len(ditlevsen_times)} windows):")
        print(f"    Variance range: {ditlevsen_var.min():.1f} → {ditlevsen_var.max():.1f}")
        print(f"    Autocorrelation range: {ditlevsen_ac.min():.3f} → {ditlevsen_ac.max():.3f}")
        print(f"    α_restore range: {ditlevsen_alpha_r.min():.3f} → {ditlevsen_alpha_r.max():.3f}")

    # ── Kramers escape time prediction ──
    # After bifurcation, barrier from low → high:
    # ΔV ∝ δ^{3/2} where δ = 1/4 - α²
    # τ_escape ~ exp(n · C · δ^{3/2})
    # We compute this theoretically and compare with observed capture rate
    kramers_delta = 0.25 - alpha_t ** 2
    kramers_delta = np.clip(kramers_delta, 0, None)
    # For the LOW→HIGH escape, the barrier is different from HIGH→LOW
    # The potential barrier from the low state scales differently
    # Use a simple model: escape rate ∝ exp(-n * c * δ^{3/2}) for some c
    # We calibrate c from the observed capture rate

    # ── Plot ──
    fig = plt.figure(figsize=(18, 16))
    gs = GridSpec(3, 3, hspace=0.38, wspace=0.35,
                  left=0.07, right=0.96, top=0.94, bottom=0.05)

    # (a) Sample trajectories with bifurcation overlay
    ax = fig.add_subplot(gs[0, 0])
    for b in range(min(30, B)):
        ax.plot(times, Q2[:, b], alpha=0.12, color=COLORS['blue'], lw=0.4)
    ax.plot(times, np.mean(Q2f, axis=1), color=COLORS['cyan'], lw=1.5,
            label='ensemble mean', zorder=5)
    # Plot upper fixed point where it exists
    mask_bif = barrier_exists
    ax.plot(times[mask_bif], q_plus_t[mask_bif], '--', color=COLORS['orange'],
            lw=1.5, label='q₊* (debris trap)', zorder=4)
    ax.plot(times[mask_bif], threshold_t[mask_bif], ':', color=COLORS['red'],
            lw=1.5, label='q₋* (threshold)', zorder=4)
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7,
               label=f'α crosses 0.5 (t={t_bif:.0f})')
    ax.set_xlabel('Time')
    ax.set_ylabel('Q₂')
    ax.set_title('(a) Trajectories: capture into debris trap')
    ax.legend(fontsize=8, loc='upper left')
    ax.grid(True)

    # (b) α ramp (downward) and δ
    ax = fig.add_subplot(gs[0, 1])
    ax.plot(times, alpha_t, color=COLORS['purple'], lw=2)
    ax.axhline(0.5, color=COLORS['red'], ls='--', lw=1, alpha=0.7, label='αc = 0.5')
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5)
    ax.fill_between(times, 0.5, alpha_t, where=alpha_t < 0.5,
                    color=COLORS['red'], alpha=0.1, label='bistable (danger)')
    ax.fill_between(times, alpha_t, 0.5, where=alpha_t >= 0.5,
                    color=COLORS['green'], alpha=0.1, label='monostable (safe)')
    ax.set_xlabel('Time')
    ax.set_ylabel('α(t)')
    ax.set_title('(b) Control parameter: safe → danger')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (c) Fraction captured
    ax = fig.add_subplot(gs[0, 2])
    ax.plot(times, frac_captured, color=COLORS['red'], lw=2)
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7,
               label=f'bifurcation (t={t_bif:.0f})')
    if t_first_capture is not None:
        ax.axvline(t_first_capture, color=COLORS['orange'], ls='-', lw=1.5,
                   alpha=0.7, label=f'first capture (t={t_first_capture:.0f})')
    ax.axhline(0.5, color=COLORS['gray'], ls=':', lw=1, alpha=0.5)
    ax.set_xlabel('Time')
    ax.set_ylabel('Fraction of replicas captured')
    ax.set_title('(c) Capture probability')
    ax.set_ylim(-0.02, 1.02)
    ax.legend(fontsize=8)
    ax.grid(True)

    # (d) Cross-replica variance (bimodality detector)
    ax = fig.add_subplot(gs[1, 0])
    kernel = np.ones(10) / 10
    var_smooth = np.convolve(cr_ews.variance, kernel, mode='same')
    ax.plot(cr_ews.times, var_smooth, color=COLORS['orange'], lw=2,
            label='cross-replica variance')
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    if t_first_capture is not None:
        ax.axvline(t_first_capture, color=COLORS['orange'], ls=':', lw=1.5, alpha=0.5)
    ax.set_xlabel('Time')
    ax.set_ylabel('Variance')
    ax.set_title('(d) Cross-replica variance (bimodality)')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (e) Skewness (upward excursions)
    ax = fig.add_subplot(gs[1, 1])
    skew_smooth = np.convolve(cr_ews.skewness, kernel, mode='same')
    ax.plot(cr_ews.times, skew_smooth, color=COLORS['pink'], lw=2,
            label='skewness')
    ax.axhline(0, color=COLORS['gray'], ls=':', lw=1)
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_ylabel('Skewness')
    ax.set_title('(e) Skewness (asymmetric excursions)')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (f) Upper-tail quantiles (flickering detector)
    ax = fig.add_subplot(gs[1, 2])
    ax.plot(times, q95, color=COLORS['cyan'], lw=1.5, label='95th percentile')
    ax.plot(times, q99, color=COLORS['blue'], lw=1.5, label='99th percentile')
    ax.plot(times, q_max, color=COLORS['purple'], lw=1, alpha=0.5, label='max')
    if np.any(mask_bif):
        ax.plot(times[mask_bif], threshold_t[mask_bif], ':', color=COLORS['red'],
                lw=1.5, label='q₋* threshold')
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_ylabel('Q₂ quantiles')
    ax.set_title('(f) Tail statistics (flickering)')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (g) Ditlevsen EWS from upper basin: variance
    ax = fig.add_subplot(gs[2, 0])
    if len(ditlevsen_times) > 0:
        ax.plot(ditlevsen_times, ditlevsen_var, 'o-', color=COLORS['orange'],
                ms=3, lw=1.5, label='upper-basin variance')
        ax.set_ylabel('Variance (upper basin)')
    else:
        ax.text(0.5, 0.5, 'No upper-basin\ndata available',
                transform=ax.transAxes, ha='center', va='center',
                fontsize=12, color=COLORS['gray'])
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_title('(g) Ditlevsen EWS: upper-basin variance')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (h) Ditlevsen EWS from upper basin: autocorrelation
    ax = fig.add_subplot(gs[2, 1])
    if len(ditlevsen_times) > 0:
        ax.plot(ditlevsen_times, ditlevsen_ac, 'o-', color=COLORS['cyan'],
                ms=3, lw=1.5, label='upper-basin AC')
        ax.axhline(1.0, color=COLORS['red'], ls=':', lw=1, alpha=0.5)
        ax.set_ylabel('Autocorrelation (upper basin)')
    else:
        ax.text(0.5, 0.5, 'No upper-basin\ndata available',
                transform=ax.transAxes, ha='center', va='center',
                fontsize=12, color=COLORS['gray'])
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_title('(h) Ditlevsen EWS: upper-basin autocorrelation')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (i) Summary: Q₂ distribution evolution (heatmap)
    ax = fig.add_subplot(gs[2, 2])
    # Bin Q₂ at selected time slices
    n_slices = 8
    slice_idx = np.linspace(0, len(times) - 1, n_slices + 2, dtype=int)[1:-1]
    max_q = max(np.percentile(Q2, 99.5), 10)
    bins = np.linspace(0, max_q, 60)

    for j, idx in enumerate(slice_idx):
        t_s = times[idx]
        a_s = alpha_t[idx]
        color_val = j / (n_slices - 1)
        c = plt.cm.coolwarm(color_val)
        hist, edges = np.histogram(Q2[idx], bins=bins, density=True)
        centers = (edges[:-1] + edges[1:]) / 2
        ax.plot(centers, hist + j * 0.001, color=c, lw=1.2,
                label=f't={t_s:.0f}, α={a_s:.2f}' if j % 2 == 0 else None)

    ax.set_xlabel('Q₂')
    ax.set_ylabel('Density (stacked)')
    ax.set_title('(i) Distribution evolution')
    ax.legend(fontsize=7, loc='upper right')
    ax.grid(True)

    fig.suptitle(f'Phase 5: Debris-Trap Scenario — n={n}, B={B}, '
                 f'α: {alpha_start}→{alpha_end}',
                 fontsize=15, fontweight='bold', color='white')
    fig.savefig(os.path.join(OUT_DIR, 'phase5_debris_trap.png'), dpi=180)
    print(f"\n  Saved: {OUT_DIR}/phase5_debris_trap.png")
    plt.close()

    # ── Summary statistics ──
    print(f"\n  Summary:")
    print(f"    Bifurcation time (α=0.5): t = {t_bif:.0f}")
    if t_first_capture is not None:
        delay = t_first_capture - t_bif
        a_at_capture = alpha_t[any_captured[0]]
        delta_at_capture = 0.25 - a_at_capture ** 2
        print(f"    First capture: t = {t_first_capture:.0f} "
              f"(delay = {delay:.0f} after bifurcation)")
        print(f"    α at first capture: {a_at_capture:.3f} "
              f"(δ = {delta_at_capture:.4f})")
    print(f"    Final capture fraction: {frac_captured[-1]:.3f}")

    if len(ditlevsen_var) > 0 and len(ditlevsen_var) > 5:
        # Check if Ditlevsen EWS show increasing trend in upper basin
        from scipy.stats import kendalltau
        tau_var, p_var = kendalltau(ditlevsen_times, ditlevsen_var)
        tau_ac, p_ac = kendalltau(ditlevsen_times, ditlevsen_ac)
        print(f"\n  Ditlevsen EWS check (from upper basin):")
        print(f"    Variance trend (Kendall τ): {tau_var:.3f} (p={p_var:.4f})")
        print(f"    Autocorrelation trend (Kendall τ): {tau_ac:.3f} (p={p_ac:.4f})")
        if tau_var > 0 and p_var < 0.05:
            print(f"    → Variance IS increasing (Ditlevsen EWS active)")
        else:
            print(f"    → Variance NOT significantly increasing")
        if tau_ac > 0 and p_ac < 0.05:
            print(f"    → Autocorrelation IS increasing (Ditlevsen EWS active)")
        else:
            print(f"    → Autocorrelation NOT significantly increasing")

    # ── Key physics message ──
    print(f"\n  KEY INSIGHT:")
    print(f"    The low state does NOT show critical slowing down —")
    print(f"    its restoring rate f'(0) ≈ −γ is independent of α.")
    print(f"    Standard Ditlevsen EWS (variance/AC near equilibrium)")
    print(f"    FAIL to predict capture from the low basin.")
    print(f"    ")
    print(f"    What DOES work as an early warning:")
    print(f"    • Upper-tail excursions (flickering)")
    print(f"    • Cross-replica variance spike (bimodality onset)")
    print(f"    • Positive skewness (asymmetric upward fluctuations)")
    print(f"    • Fraction-captured curve (direct monitoring)")

    return result, frac_captured


# ═══════════════════════════════════════════════════════════════
# Phase 6: Physical Debris Scenario — α(t) = C/λ(t)
# ═══════════════════════════════════════════════════════════════

def phase6(n=1000, B=4096, T=1500, dt_record=1.0, alpha_start=0.65,
           alpha_end=0.06, Tw=50):
    """
    The physically correct debris scenario with GROWING constellation.

    n(t) increases over time — more satellites launched. This drives:
      α(t) = K_phys · γ / λ(t)  where  λ(t) = n(t) - θ√n(t)

    K_phys is a CONSTANT set by orbital collision physics. As n grows,
    α shrinks, the debris trap appears and deepens, and eventually the
    baseline debris overtakes the cascade threshold.

    Unlike the previous version, n(t) actually grows in the simulation,
    so station 1 capacity, throughput, n₂ʰⁱ, and absolute fixed points
    all evolve self-consistently.
    """
    print("\n" + "="*70)
    print("PHASE 6: Physical Debris — Growing Constellation")
    print("="*70)

    gamma = 1.0
    theta = 0.5
    epsilon = 0.01

    # Back out K_phys from initial conditions:
    # α_start = K_phys · γ / λ₀,  λ₀ = n - θ√n
    n_0 = n
    lam_0 = n_0 - theta * np.sqrt(n_0)
    K_phys = alpha_start * lam_0 / gamma

    # Find n at which α = alpha_end:
    # alpha_end = K_phys * gamma / (n_end - theta*sqrt(n_end))
    # Solve numerically
    from scipy.optimize import brentq
    f_alpha = lambda nn: K_phys * gamma / (nn - theta * np.sqrt(nn)) - alpha_end
    n_end = brentq(f_alpha, n_0, n_0 * 50)

    # Find n at bifurcation (α = 0.5)
    f_bif = lambda nn: K_phys * gamma / (nn - theta * np.sqrt(nn)) - 0.5
    if f_bif(n_0) * f_bif(n_end) < 0:
        n_bif = brentq(f_bif, n_0, n_end)
    else:
        n_bif = n_0  # already past bifurcation

    # Linear growth: n(t) = n_0 + r_n * t
    r_n = (n_end - n_0) / T

    # Derived schedules
    def n_schedule(t):
        return n_0 + r_n * t

    def alpha_from_n(nn):
        lam = nn - theta * np.sqrt(nn)
        return K_phys * gamma / max(lam, 1.0)

    def alpha_schedule(t):
        return alpha_from_n(n_schedule(t))

    # Bifurcation time
    t_bif = (n_bif - n_0) / r_n

    lam_end = n_end - theta * np.sqrt(n_end)
    lam_bif = n_bif - theta * np.sqrt(n_bif)

    print(f"  n₀ = {n_0}, n_end = {n_end:.0f} (growth rate = {r_n:.2f}/t)")
    print(f"  K_phys = {K_phys:.1f} (CONSTANT — orbital collision physics)")
    print(f"  λ₀ = {lam_0:.1f}, λ_end = {lam_end:.1f}")
    print(f"  α₀ = {alpha_start:.3f} → α_end = {alpha_end:.3f}")
    print(f"  Bifurcation: n = {n_bif:.0f}, α = 0.5, t = {t_bif:.0f}")
    print(f"  √ε = {np.sqrt(epsilon):.3f} — deterministic capture at α ≈ √ε")
    print(f"  Replicas: B = {B}, all starting LOW (Q₂ = 0)")

    # Simulate
    params = NetworkParams(n=n_0, theta=theta, gamma=gamma,
                           alpha=alpha_start, epsilon=epsilon)
    sim = TandemSimulator(params, B=B, dt_sim=0.005, seed=2024)
    print(f"  Simulating T={T}...", flush=True)
    t_start = time.time()
    result = sim.simulate(T=T, dt_record=dt_record, Q2_init=0,
                          alpha_schedule=alpha_schedule,
                          n_schedule=n_schedule)
    elapsed = time.time() - t_start
    print(f"  Done in {elapsed:.1f}s")

    times = result['times']
    Q2 = result['Q2']
    alpha_t = result['alpha_t']
    n_t = result['n_t']
    Q2f = Q2.astype(np.float64)

    # ── Compute time-varying landscape using ACTUAL n(t) ──
    lam_t = n_t - theta * np.sqrt(n_t)
    n2hi_t = lam_t / gamma

    threshold_t = np.full(len(times), np.nan)
    q_plus_t = np.full(len(times), np.nan)
    barrier_exists = np.zeros(len(times), dtype=bool)
    delta_t = np.zeros(len(times))
    baseline_t = epsilon * n2hi_t  # ε · n₂ʰⁱ(t) — grows!

    for i, a in enumerate(alpha_t):
        disc = 1 - 4 * a ** 2
        delta_t[i] = max(0.25 - a ** 2, 0)
        if disc > 0 and a < 0.5:
            sq = np.sqrt(disc)
            threshold_t[i] = (1 - sq) / 2 * n2hi_t[i]
            q_plus_t[i] = (1 + sq) / 2 * n2hi_t[i]
            barrier_exists[i] = True

    # ── Capture statistics ──
    frac_captured = np.zeros(len(times))
    first_passage = np.full(B, np.inf)
    for i in range(len(times)):
        if barrier_exists[i]:
            captured_now = Q2[i] > threshold_t[i]
            frac_captured[i] = np.mean(captured_now)
            newly = captured_now & np.isinf(first_passage)
            if np.any(newly):
                first_passage[newly] = times[i]

    n_captured = np.sum(np.isfinite(first_passage))
    print(f"  Captured: {n_captured}/{B} = {n_captured/B:.3f}")
    if n_captured > 0:
        fp_finite = first_passage[np.isfinite(first_passage)]
        print(f"  Mean first-passage time: {np.mean(fp_finite):.1f}")
        any_cap_idx = np.where(frac_captured > 0)[0]
        if len(any_cap_idx) > 0:
            t_first = times[any_cap_idx[0]]
            print(f"  First capture at t = {t_first:.1f}, "
                  f"α = {alpha_t[any_cap_idx[0]]:.3f}, "
                  f"n = {n_t[any_cap_idx[0]]}, "
                  f"delay from bif = {t_first - t_bif:.0f}")

    # ── EWS: cross-replica ──
    cr_ews = compute_cross_replica_ews(Q2, times)

    # ── Flickering: tail quantiles ──
    q95 = np.percentile(Q2f, 95, axis=1)
    q99 = np.percentile(Q2f, 99, axis=1)

    # ── Skewness ──
    kernel = np.ones(15) / 15
    skew_smooth = np.convolve(cr_ews.skewness, kernel, mode='same')

    # ── Ditlevsen EWS on captured replicas ──
    ditlevsen_times = []
    ditlevsen_var = []
    ditlevsen_ac = []
    hw = 25
    for i in range(hw, len(times) - hw):
        if not barrier_exists[i]:
            continue
        upper_mask = Q2[i] > threshold_t[i]
        if np.sum(upper_mask) < 30:
            continue
        window = Q2f[i - hw:i + hw, upper_mask]
        stays = np.all(window > threshold_t[i] * 0.3, axis=0)
        if np.sum(stays) < 20:
            continue
        ws = window[:, stays]
        ditlevsen_times.append(times[i])
        ditlevsen_var.append(np.mean(np.var(ws, axis=0)))
        acs = []
        for b in range(ws.shape[1]):
            ts = ws[:, b] - np.mean(ws[:, b])
            if np.sum(ts ** 2) > 0:
                ac = np.clip(np.sum(ts[:-1] * ts[1:]) / np.sum(ts ** 2), 0.01, 0.999)
                acs.append(ac)
        ditlevsen_ac.append(np.mean(acs) if acs else 0)

    ditlevsen_times = np.array(ditlevsen_times)
    ditlevsen_var = np.array(ditlevsen_var)
    ditlevsen_ac = np.array(ditlevsen_ac)

    # ── Plot ──
    fig = plt.figure(figsize=(18, 18))
    gs = GridSpec(4, 3, hspace=0.38, wspace=0.35,
                  left=0.07, right=0.96, top=0.95, bottom=0.04)

    # (a) Trajectories with CORRECT fixed points
    ax = fig.add_subplot(gs[0, 0])
    for b in range(min(30, B)):
        ax.plot(times, Q2[:, b], alpha=0.12, color=COLORS['blue'], lw=0.4)
    ax.plot(times, np.mean(Q2f, axis=1), color=COLORS['cyan'], lw=1.5,
            label='ensemble mean', zorder=5)
    m = barrier_exists
    ax.plot(times[m], q_plus_t[m], '--', color=COLORS['orange'], lw=1.5,
            label='q₊* (debris trap)')
    ax.plot(times[m], threshold_t[m], ':', color=COLORS['red'], lw=1.5,
            label='q₋* (threshold)')
    ax.plot(times, baseline_t, '-', color=COLORS['blue'], lw=1, alpha=0.5,
            label='ε·n₂ʰⁱ (baseline)')
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7,
               label=f'α = 0.5 (t={t_bif:.0f})')
    ax.set_xlabel('Time')
    ax.set_ylabel('Q₂ (absolute)')
    ax.set_title('(a) Trajectories — growing constellation')
    ax.legend(fontsize=7, loc='upper left')
    ax.grid(True)

    # (b) α(t) and n(t) on twin axis
    ax = fig.add_subplot(gs[0, 1])
    ax.plot(times, alpha_t, color=COLORS['purple'], lw=2.5, label='α(t) = K/λ(t)')
    ax.axhline(0.5, color=COLORS['red'], ls='--', lw=1.5, alpha=0.7, label='αc = 0.5')
    ax.axhline(np.sqrt(epsilon), color=COLORS['blue'], ls=':', lw=1,
               alpha=0.7, label=f'√ε = {np.sqrt(epsilon):.2f}')
    ax.fill_between(times, alpha_t, 0.5, where=alpha_t >= 0.5,
                    color=COLORS['green'], alpha=0.1)
    ax.fill_between(times, 0.5, alpha_t, where=alpha_t < 0.5,
                    color=COLORS['red'], alpha=0.1)
    ax.set_xlabel('Time')
    ax.set_ylabel('α(t)')
    ax2b = ax.twinx()
    ax2b.plot(times, n_t, color=COLORS['cyan'], lw=1.5, ls=':')
    ax2b.set_ylabel('n(t) — constellation size', color=COLORS['cyan'])
    ax2b.tick_params(axis='y', labelcolor=COLORS['cyan'])
    ax.set_title('(b) α(t) and constellation growth')
    ax.legend(fontsize=7, loc='right')
    ax.grid(True)

    # (c) Key scales: n₂ʰⁱ, baseline, threshold, K_phys
    ax = fig.add_subplot(gs[0, 2])
    ax.plot(times, n2hi_t, color=COLORS['cyan'], lw=2, label='n₂ʰⁱ(t) = λ(t)/γ')
    ax.plot(times, baseline_t, color=COLORS['blue'], lw=2, label=f'ε·n₂ʰⁱ (baseline)')
    ax.plot(times[m], threshold_t[m], ':', color=COLORS['red'], lw=2,
            label='q₋* (threshold)')
    ax.axhline(K_phys, color=COLORS['green'], ls='--', lw=1.5, alpha=0.7,
               label=f'K_phys = {K_phys:.0f} (constant)')
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1, alpha=0.5)
    ax.set_xlabel('Time')
    ax.set_ylabel('Debris count')
    ax.set_title('(c) Scales: baseline rising toward threshold')
    ax.legend(fontsize=7)
    ax.grid(True)

    # (d) Capture fraction
    ax = fig.add_subplot(gs[1, 0])
    ax.plot(times, frac_captured, color=COLORS['red'], lw=2)
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7,
               label=f'bifurcation (t={t_bif:.0f})')
    ax.set_xlabel('Time')
    ax.set_ylabel('Fraction captured')
    ax.set_title('(d) Capture probability')
    ax.set_ylim(-0.02, 1.02)
    ax.legend(fontsize=8)
    ax.grid(True)

    # (e) Cross-replica variance
    ax = fig.add_subplot(gs[1, 1])
    var_smooth = np.convolve(cr_ews.variance, kernel, mode='same')
    ax.plot(cr_ews.times, var_smooth, color=COLORS['orange'], lw=2,
            label='cross-replica variance')
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_ylabel('Variance')
    ax.set_title('(e) Cross-replica variance (bimodality)')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (f) Skewness
    ax = fig.add_subplot(gs[1, 2])
    ax.plot(cr_ews.times, skew_smooth, color=COLORS['pink'], lw=2,
            label='skewness (smoothed)')
    ax.axhline(0, color=COLORS['gray'], ls=':', lw=1)
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_ylabel('Skewness')
    ax.set_title('(f) Skewness — precursor of capture')
    ax.legend(fontsize=8)
    ax.grid(True)

    # (g) Tail quantiles (flickering) vs threshold
    ax = fig.add_subplot(gs[2, 0])
    ax.plot(times, q95, color=COLORS['cyan'], lw=1.5, label='95th pctile')
    ax.plot(times, q99, color=COLORS['blue'], lw=1.5, label='99th pctile')
    ax.plot(times, baseline_t, '-', color=COLORS['blue'], lw=1, alpha=0.3,
            label='baseline ε·n₂ʰⁱ')
    if np.any(m):
        ax.plot(times[m], threshold_t[m], ':', color=COLORS['red'], lw=1.5,
                label='q₋* threshold')
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_ylabel('Q₂ quantiles')
    ax.set_title('(g) Tail statistics (flickering)')
    ax.legend(fontsize=7)
    ax.grid(True)

    # (h) Ditlevsen EWS: upper-basin variance
    ax = fig.add_subplot(gs[2, 1])
    if len(ditlevsen_times) > 0:
        ax.plot(ditlevsen_times, ditlevsen_var, 'o-', color=COLORS['orange'],
                ms=2, lw=1, label='upper-basin variance')
    else:
        ax.text(0.5, 0.5, 'No upper-basin\ndata yet',
                transform=ax.transAxes, ha='center', va='center',
                fontsize=12, color=COLORS['gray'])
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_ylabel('Variance (upper basin)')
    ax.set_title('(h) Ditlevsen EWS: upper-basin variance')
    if len(ditlevsen_times) > 0:
        ax.legend(fontsize=8)
    ax.grid(True)

    # (i) Ditlevsen EWS: upper-basin autocorrelation
    ax = fig.add_subplot(gs[2, 2])
    if len(ditlevsen_times) > 0:
        ax.plot(ditlevsen_times, ditlevsen_ac, 'o-', color=COLORS['cyan'],
                ms=2, lw=1, label='upper-basin AC')
        ax.axhline(1.0, color=COLORS['red'], ls=':', lw=1, alpha=0.5)
    else:
        ax.text(0.5, 0.5, 'No upper-basin\ndata yet',
                transform=ax.transAxes, ha='center', va='center',
                fontsize=12, color=COLORS['gray'])
    ax.axvline(t_bif, color=COLORS['yellow'], ls='--', lw=1.5, alpha=0.7)
    ax.set_xlabel('Time')
    ax.set_ylabel('Autocorrelation')
    ax.set_title('(i) Ditlevsen EWS: upper-basin AC')
    if len(ditlevsen_times) > 0:
        ax.legend(fontsize=8)
    ax.grid(True)

    # (j) Distribution evolution
    ax = fig.add_subplot(gs[3, :])
    n_slices = 12
    slice_idx = np.linspace(0, len(times) - 1, n_slices + 2, dtype=int)[1:-1]
    max_q = max(np.percentile(Q2, 99.9), 20)
    bins = np.linspace(0, max_q, 80)

    for j, idx in enumerate(slice_idx):
        t_s = times[idx]
        a_s = alpha_t[idx]
        n_s = n_t[idx]
        c = plt.cm.RdYlBu_r(j / (n_slices - 1))
        hist, edges = np.histogram(Q2[idx], bins=bins, density=True)
        centers = (edges[:-1] + edges[1:]) / 2
        label = f't={t_s:.0f}, α={a_s:.2f}, n={n_s}' if j % 3 == 0 else None
        ax.plot(centers, hist + j * 0.0003, color=c, lw=1.2, label=label)

    ax.set_xlabel('Q₂ (debris population)')
    ax.set_ylabel('Density (stacked)')
    ax.set_title('(j) Distribution evolution: from safe to Kessler syndrome')
    ax.legend(fontsize=7, ncol=4, loc='upper right')
    ax.grid(True)

    fig.suptitle(f'Phase 6: Growing Constellation — n: {n_0}→{n_end:.0f}, '
                 f'K_phys={K_phys:.0f} (const), B={B}\n'
                 f'α: {alpha_start:.2f}→{alpha_end:.2f}, '
                 f'bifurcation at t={t_bif:.0f} (n={n_bif:.0f})',
                 fontsize=14, fontweight='bold', color='white')
    fig.savefig(os.path.join(OUT_DIR, 'phase6_physical_debris.png'), dpi=180)
    print(f"\n  Saved: {OUT_DIR}/phase6_physical_debris.png")
    plt.close()

    # ── Summary ──
    print(f"\n  ══ GROWING CONSTELLATION SUMMARY ══")
    print(f"  K_phys = {K_phys:.1f} (constant)")
    print(f"  n: {n_0} → {n_end:.0f} (growth rate {r_n:.2f}/t)")
    print(f"  α: {alpha_start:.3f} → {alpha_end:.3f}")
    print(f"  Bifurcation: t = {t_bif:.0f}, n = {n_bif:.0f}")
    print(f"  Final n₂ʰⁱ = {n2hi_t[-1]:.0f}, baseline = {baseline_t[-1]:.1f}")
    print(f"  Captured at end: {n_captured}/{B} ({n_captured/B:.1%})")
    if n_captured > 0:
        print(f"  Mean capture time: {np.mean(fp_finite):.0f}")
        print(f"  Delay after bifurcation: {np.mean(fp_finite) - t_bif:.0f}")

    return result

def main():
    parser = argparse.ArgumentParser(description="EWS analysis for tandem network")
    parser.add_argument("--phase", type=int, default=0,
                        help="Run specific phase (1-6), or 0 for all")
    parser.add_argument("--n", type=int, default=1000, help="Station 1 servers")
    parser.add_argument("--B", type=int, default=4096, help="Number of replicas")
    parser.add_argument("--T", type=float, default=800, help="Simulation time")
    parser.add_argument("--tau_r", type=float, default=500, help="Ramping duration")
    parser.add_argument("--alpha_start", type=float, default=0.65,
                        help="Phase 6: initial α (> 0.5 = safe)")
    parser.add_argument("--alpha_end", type=float, default=0.06,
                        help="Phase 6: final α (< √ε ≈ 0.1 for capture)")
    parser.add_argument("--cpu", action="store_true", help="Force CPU mode")
    args = parser.parse_args()

    if args.cpu:
        import tandem_sim
        tandem_sim.GPU_AVAILABLE = False
        print("[main] Forced CPU mode")

    print(f"\n{'='*70}")
    print(f"  EWS ANALYSIS FOR TANDEM LOSS / ∞-SERVER NETWORK")
    print(f"  Saddle-node bifurcation at α = 0.5")
    print(f"  n={args.n}, B={args.B}, T={args.T}, τ_r={args.tau_r}")
    print(f"{'='*70}")

    cal = None

    if args.phase in (0, 1):
        phase1(n=args.n, B=args.B, T=args.T, tau_r=args.tau_r)

    if args.phase in (0, 2):
        cal = phase2(n=args.n, B=min(args.B, 2048))

    if args.phase in (0, 3):
        if cal is None:
            print("\n  Running Phase 2 first (needed for Phase 3)...")
            cal = phase2(n=args.n, B=min(args.B, 2048))
        phase3(cal=cal, n=args.n)

    if args.phase in (0, 4):
        phase4(n=args.n, B=args.B, T=args.T, tau_r=args.tau_r)

    if args.phase in (0, 5):
        phase5(n=args.n, B=args.B, T=int(args.T * 1.5), tau_r=int(args.tau_r * 1.2))

    if args.phase in (0, 6):
        phase6(n=args.n, B=args.B, T=int(args.T * 2),
               alpha_start=args.alpha_start, alpha_end=args.alpha_end)

    print(f"\n{'='*70}")
    print(f"  ALL DONE — results in ./{OUT_DIR}/")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
