"""
Tipping-time estimation for the tandem network.

Implements:
  1. Moment-based estimator: regress α_restore(t)² on t → zero crossing = t_c
  2. Approximate MLE using Strang splitting for the nonlinear SDE
  3. Parametric bootstrap for confidence intervals

References:
  - Ditlevsen & Ditlevsen (2023), Nature Communications 14:4254
  - Pilipovic, Samson & Ditlevsen (2022), arXiv:2211.11884 (Strang splitting)
"""

import numpy as np
from scipy.optimize import minimize, minimize_scalar
from scipy.stats import norm
from dataclasses import dataclass
from typing import Optional, Tuple
import warnings


@dataclass
class TippingEstimate:
    """Result of tipping-time estimation."""
    method: str
    t_c: float                    # estimated tipping time
    t_0: float                    # estimated start of ramping
    tau_r: float                  # estimated ramping duration
    alpha_0: float                # initial alpha
    ci_95: Tuple[float, float]    # 95% confidence interval for t_c
    ci_66: Tuple[float, float]    # 66% confidence interval for t_c
    params: dict                  # all estimated parameters
    bootstrap_tc: Optional[np.ndarray] = None  # bootstrap distribution of t_c


# ═══════════════════════════════════════════════════════════════
# 1. Moment-Based Estimator
# ═══════════════════════════════════════════════════════════════

def estimate_tipping_moment(alpha_restore_sq: np.ndarray,
                             times: np.ndarray,
                             t0_range: Tuple[float, float] = None,
                             Tw_range: Tuple[float, float] = None
                             ) -> TippingEstimate:
    """
    Moment-based tipping time estimator.

    Uses the fact that α_restore(t)² ∝ δ(t), and under linear ramping
    δ(t) decreases linearly. So we fit a line to α_restore(t)² and
    find its zero crossing.

    This is the analog of Ditlevsen's Fig. 5f.

    Args:
        alpha_restore_sq: α_restore(t)² values (from EWS)
        times: corresponding time points
        t0_range: (t0_min, t0_max) to search for ramping onset
        Tw_range: not used here, kept for API compatibility

    Returns:
        TippingEstimate
    """
    # Find the point where α_restore² starts declining
    # Simple approach: fit line to all data and find zero crossing
    valid = np.isfinite(alpha_restore_sq) & (alpha_restore_sq > 0)
    t_valid = times[valid]
    y_valid = alpha_restore_sq[valid]

    if len(t_valid) < 5:
        return TippingEstimate(
            method="moment", t_c=np.inf, t_0=0, tau_r=np.inf,
            alpha_0=0, ci_95=(np.nan, np.nan), ci_66=(np.nan, np.nan),
            params={}
        )

    # Linear regression: α_r² = a + b*t
    coeffs = np.polyfit(t_valid, y_valid, 1)
    slope, intercept = coeffs

    if slope >= 0:
        # Not declining — no tipping detected
        warnings.warn("α_restore² is not declining; no tipping detected")
        return TippingEstimate(
            method="moment", t_c=np.inf, t_0=t_valid[0], tau_r=np.inf,
            alpha_0=np.sqrt(intercept) if intercept > 0 else 0,
            ci_95=(np.nan, np.nan), ci_66=(np.nan, np.nan),
            params={"slope": slope, "intercept": intercept}
        )

    # Zero crossing: a + b*t_c = 0 → t_c = -a/b
    t_c = -intercept / slope

    # Estimate t_0: where α_r² = α_r²(baseline)
    alpha_r_sq_0 = y_valid[0]  # use first value as baseline
    t_0 = t_valid[0]
    tau_r = t_c - t_0

    # Uncertainty from regression
    residuals = y_valid - np.polyval(coeffs, t_valid)
    mse = np.mean(residuals ** 2)
    # Propagate uncertainty to t_c
    n = len(t_valid)
    t_bar = np.mean(t_valid)
    Sxx = np.sum((t_valid - t_bar) ** 2)
    se_slope = np.sqrt(mse / Sxx)
    se_intercept = np.sqrt(mse * np.mean(t_valid ** 2) / Sxx)

    # Delta method for t_c = -intercept/slope
    dt_c = np.sqrt(
        (se_intercept / slope) ** 2 +
        (intercept * se_slope / slope ** 2) ** 2
    )

    return TippingEstimate(
        method="moment",
        t_c=t_c,
        t_0=t_0,
        tau_r=tau_r,
        alpha_0=np.sqrt(max(alpha_r_sq_0, 0)) * 2,  # α_r = 2√(Aδ)
        ci_95=(t_c - 1.96 * dt_c, t_c + 1.96 * dt_c),
        ci_66=(t_c - 0.97 * dt_c, t_c + 0.97 * dt_c),
        params={"slope": slope, "intercept": intercept,
                "se_tc": dt_c, "mse": mse}
    )


# ═══════════════════════════════════════════════════════════════
# 2. Approximate MLE via Strang Splitting
# ═══════════════════════════════════════════════════════════════

def _hill_drift(q, Lambda, gamma, alpha, epsilon, n2hi):
    """Full drift f(q) = Λ·p̃(q) - γ·q."""
    K = alpha * n2hi
    q2 = q ** 2
    p = epsilon + (1 - epsilon) * q2 / (q2 + K ** 2 + 1e-30)
    return Lambda * p - gamma * q


def _hill_drift_deriv(q, Lambda, gamma, alpha, epsilon, n2hi):
    """Derivative f'(q) for linearisation."""
    K = alpha * n2hi
    q2 = q ** 2
    K2 = K ** 2
    denom = (q2 + K2) ** 2 + 1e-30
    dp_dq = (1 - epsilon) * 2 * q * K2 / denom
    return Lambda * dp_dq - gamma


def _strang_transition(x, x_next, dt, alpha_t, Lambda, gamma, epsilon, n2hi, sigma):
    """
    Strang splitting transition density: log p(x_next | x).

    Decompose drift f(q) = f_lin(q) + f_nl(q), where:
      f_lin(q) = -α_restore · (q - μ*)  [OU part]
      f_nl(q) = f(q) - f_lin(q)          [residual nonlinearity]

    Strang step:
      1. Half step nonlinear: x* = x + f_nl(x) · dt/2
      2. Full step linear:    x** ~ N(μ + (x* - μ)e^{-α·dt}, σ²(1-e^{-2α·dt})/(2α))
      3. Half step nonlinear: x*** = x** + f_nl(x**) · dt/2

    We evaluate: x_next ≈ x*** → invert to get x**, then evaluate
    the Gaussian density of the OU step.
    """
    # Find the fixed point for current alpha
    # Approximate: solve f(q*) = 0 numerically
    from scipy.optimize import brentq
    f = lambda q: _hill_drift(q, Lambda, gamma, alpha_t, epsilon, n2hi)

    # Search for upper fixed point
    try:
        q_star = brentq(f, 0.5 * n2hi, 1.1 * n2hi)
    except ValueError:
        q_star = 0.5 * n2hi  # fallback if no root

    alpha_restore = abs(_hill_drift_deriv(q_star, Lambda, gamma, alpha_t, epsilon, n2hi))
    alpha_restore = max(alpha_restore, 1e-6)

    # OU parameters at fixed point
    mu = q_star
    f_lin = lambda q: -alpha_restore * (q - mu)
    f_nl = lambda q: _hill_drift(q, Lambda, gamma, alpha_t, epsilon, n2hi) - f_lin(q)

    # Forward Strang step from x
    x_half = x + f_nl(x) * dt / 2.0

    # Invert the second nonlinear half-step from x_next
    # x** ≈ x_next - f_nl(x_next) * dt/2
    x_mid = x_next - f_nl(x_next) * dt / 2.0

    # OU transition density: x_mid | x_half
    e_adt = np.exp(-alpha_restore * dt)
    ou_mean = mu + (x_half - mu) * e_adt
    ou_var = sigma ** 2 * (1 - e_adt ** 2) / (2 * alpha_restore + 1e-30)
    ou_var = max(ou_var, 1e-30)

    log_p = -0.5 * np.log(2 * np.pi * ou_var) - 0.5 * (x_mid - ou_mean) ** 2 / ou_var
    return log_p


def estimate_tipping_mle(Q2_trajectory: np.ndarray,
                          times: np.ndarray,
                          params_dict: dict,
                          t0_fixed: Optional[float] = None,
                          alpha_0: float = 0.3,
                          alpha_c: float = 0.5,
                          ) -> TippingEstimate:
    """
    Approximate MLE for the tipping time.

    Fits the 1D SDE model:
        dQ₂ = [Λ·p̃(Q₂; α(t)) - γ·Q₂] dt + σ·dB

    with α(t) ramping linearly from α₀ to αc over [t₀, t₀+τ_r].

    Args:
        Q2_trajectory: (n_times,) mean trajectory or single replica
        times: (n_times,)
        params_dict: must contain 'Lambda', 'gamma', 'epsilon', 'n2hi'
        t0_fixed: if given, fix t₀
        alpha_0: initial alpha
        alpha_c: critical alpha

    Returns:
        TippingEstimate
    """
    Lambda = params_dict['Lambda']
    gamma = params_dict['gamma']
    epsilon = params_dict['epsilon']
    n2hi = params_dict['n2hi']

    Q2 = Q2_trajectory.astype(np.float64)
    dt = times[1] - times[0]

    def neg_log_likelihood(theta):
        """theta = (tau_r, sigma, t0) or (tau_r, sigma) if t0 fixed."""
        if t0_fixed is not None:
            tau_r, log_sigma = theta
            t0 = t0_fixed
        else:
            tau_r, log_sigma, t0 = theta

        sigma = np.exp(log_sigma)
        tau_r = max(tau_r, 10.0)

        nll = 0.0
        for i in range(1, len(Q2)):
            t = times[i - 1]
            if t < t0:
                alpha_t = alpha_0
            else:
                alpha_t = min(alpha_c, alpha_0 + (alpha_c - alpha_0) * (t - t0) / tau_r)

            try:
                log_p = _strang_transition(
                    Q2[i - 1], Q2[i], dt, alpha_t,
                    Lambda, gamma, epsilon, n2hi, sigma
                )
                nll -= log_p
            except Exception:
                nll += 1e6

        return nll

    # Optimise
    if t0_fixed is not None:
        x0 = [500.0, np.log(np.std(Q2) * 0.1)]  # initial guess
        bounds = [(50, 5000), (-5, 5)]
    else:
        x0 = [500.0, np.log(np.std(Q2) * 0.1), times[0]]
        bounds = [(50, 5000), (-5, 5), (times[0], times[-1] * 0.5)]

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        result = minimize(neg_log_likelihood, x0, method='L-BFGS-B',
                         bounds=bounds, options={'maxiter': 200, 'ftol': 1e-6})

    if t0_fixed is not None:
        tau_r_hat = max(result.x[0], 10)
        sigma_hat = np.exp(result.x[1])
        t0_hat = t0_fixed
    else:
        tau_r_hat = max(result.x[0], 10)
        sigma_hat = np.exp(result.x[1])
        t0_hat = result.x[2]

    t_c_hat = t0_hat + tau_r_hat

    return TippingEstimate(
        method="mle_strang",
        t_c=t_c_hat,
        t_0=t0_hat,
        tau_r=tau_r_hat,
        alpha_0=alpha_0,
        ci_95=(np.nan, np.nan),  # to be filled by bootstrap
        ci_66=(np.nan, np.nan),
        params={
            "sigma": sigma_hat,
            "nll": result.fun,
            "success": result.success,
        }
    )


# ═══════════════════════════════════════════════════════════════
# 3. Parametric Bootstrap
# ═══════════════════════════════════════════════════════════════

def bootstrap_tipping_time(estimator_fn, sim_fn, n_bootstrap: int = 200,
                            seed: int = 42) -> np.ndarray:
    """
    Parametric bootstrap for tipping-time confidence intervals.

    Args:
        estimator_fn: callable() -> TippingEstimate (uses one simulated trajectory)
        sim_fn: callable(seed) -> trajectory (generates one replica from fitted model)
        n_bootstrap: number of bootstrap replications

    Returns:
        tc_samples: (n_bootstrap,) array of bootstrapped t_c estimates
    """
    rng = np.random.RandomState(seed)
    tc_samples = []

    for b in range(n_bootstrap):
        try:
            trajectory = sim_fn(seed=rng.randint(0, 2**31))
            est = estimator_fn(trajectory)
            if np.isfinite(est.t_c):
                tc_samples.append(est.t_c)
        except Exception as e:
            warnings.warn(f"Bootstrap iteration {b} failed: {e}")

    return np.array(tc_samples)


# ═══════════════════════════════════════════════════════════════
# 4. Normal-Form Calibration (Phase 2)
# ═══════════════════════════════════════════════════════════════

def calibrate_normal_form(alpha_values: np.ndarray,
                           variance_values: np.ndarray,
                           autocorr_values: np.ndarray,
                           mean_values: np.ndarray,
                           dt: float) -> dict:
    """
    Calibrate the normal-form parameters (A, m, σ) from equilibrium
    simulations at various α values.

    Theory predicts:
        α_restore(δ) = 2√(Aδ),  where δ = 1/4 - α²
        γ²(δ) = σ² / (2α_restore) = σ² / (4√(Aδ))  [∝ δ^{-1/2}]
        ρ(δ) = exp(-α_restore · dt)

    Args:
        alpha_values: (K,) different α values
        variance_values: (K,) measured variance at each α
        autocorr_values: (K,) measured autocorrelation at each α
        mean_values: (K,) measured mean Q₂ at each α
        dt: observation time step

    Returns:
        dict with fitted A, m, sigma, and diagnostics
    """
    delta = 0.25 - alpha_values ** 2

    # From autocorrelation: α_restore = -log(ρ)/dt
    alpha_restore = -np.log(np.clip(autocorr_values, 1e-6, 1 - 1e-6)) / dt

    # From variance: σ² = 2·α_restore·γ²
    sigma_sq = 2 * alpha_restore * variance_values

    # Fit: α_restore² = 4Aδ → linear regression of α_restore² on δ
    valid = (delta > 0) & (alpha_restore > 0)
    if np.sum(valid) < 3:
        warnings.warn("Too few valid points for normal-form calibration")
        return {"A": np.nan, "m": np.nan, "sigma": np.nan}

    coeffs = np.polyfit(delta[valid], alpha_restore[valid] ** 2, 1)
    A_times_4 = coeffs[0]  # slope = 4A
    A = A_times_4 / 4.0

    # σ² should be approximately constant
    sigma = np.sqrt(np.median(sigma_sq[valid]))

    # Mean: μ(δ) = m + √(δ/A) → fit m from intercept
    sqrt_delta_over_A = np.sqrt(delta[valid] / A) if A > 0 else np.zeros(np.sum(valid))
    m_coeffs = np.polyfit(sqrt_delta_over_A, mean_values[valid], 1)
    m = m_coeffs[1]  # intercept

    # Verify δ^{-1/2} scaling of variance
    log_var = np.log(variance_values[valid])
    log_delta = np.log(delta[valid])
    scaling_coeffs = np.polyfit(log_delta, log_var, 1)
    scaling_exponent = scaling_coeffs[0]  # should be ≈ -0.5

    return {
        "A": A,
        "m": m,
        "sigma": sigma,
        "sigma_sq_values": sigma_sq,
        "alpha_restore_values": alpha_restore,
        "scaling_exponent": scaling_exponent,
        "r_squared": 1 - np.var(alpha_restore[valid] ** 2 - np.polyval(coeffs, delta[valid])) /
                         np.var(alpha_restore[valid] ** 2),
    }


# ═══════════════════════════════════════════════════════════════
# 5. Combined estimation pipeline
# ═══════════════════════════════════════════════════════════════

def full_estimation_pipeline(ews_result, times, params_dict,
                              baseline_end: float,
                              alpha_0: float = 0.3):
    """
    Run both moment-based and MLE estimators.

    Args:
        ews_result: EWSResult from running-window computation
        times: corresponding time array
        params_dict: network parameters dict
        baseline_end: time before which data is baseline
        alpha_0: initial alpha

    Returns:
        dict with moment and mle estimates
    """
    # Moment-based
    mask_after = ews_result.times > baseline_end
    if np.any(mask_after):
        moment_est = estimate_tipping_moment(
            ews_result.A_delta[mask_after],
            ews_result.times[mask_after],
        )
    else:
        moment_est = None

    return {
        "moment": moment_est,
    }
