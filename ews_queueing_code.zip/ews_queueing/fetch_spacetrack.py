"""
fetch_spacetrack.py — Download and process Space-Track.org data
for the EWS debris pipeline.

Requires a free Space-Track account: https://www.space-track.org/auth/createAccount

Usage:
  # Set credentials (or use --user / --password flags)
  export SPACETRACK_USER="your@email.com"
  export SPACETRACK_PASSWORD="yourpassword"

  # Fetch all LEO data and save CSV
  python fetch_spacetrack.py --alt_min 500 --alt_max 600 --output shell_500_600.csv

  # Fetch with explicit credentials
  python fetch_spacetrack.py --user you@email.com --password secret --alt_min 200 --alt_max 2000

  # If you already have a SATCAT JSON dump, process it offline:
  python fetch_spacetrack.py --offline satcat.json --alt_min 500 --alt_max 600

Then run the EWS pipeline:
  python real_data_pipeline.py --csv shell_500_600.csv --Tw 10 --baseline 1990

Data sources:
  - SATCAT: object catalog with type, launch/decay dates, RCS
  - GP: current orbital elements (for altitude filtering)
  - GP_HISTORY: historical orbital elements (optional, for refined altitude tracking)

Notes:
  - Space-Track rate limits: max 30 requests/minute, 300/hour
  - SATCAT has ~60k objects; GP has ~30k current objects
  - Full GP_HISTORY is enormous; we use SATCAT + current GP for altitude
  - Objects without orbital data use RCS and object type for classification
"""

import os
import sys
import json
import time
import argparse
import numpy as np
from datetime import datetime, timedelta
from collections import defaultdict
from typing import Optional


# ═══════════════════════════════════════════════════════════════
# 1. Space-Track API Client
# ═══════════════════════════════════════════════════════════════

class SpaceTrackClient:
    """Simple Space-Track.org API client."""

    BASE_URL = "https://www.space-track.org"
    LOGIN_URL = f"{BASE_URL}/ajaxauth/login"

    def __init__(self, username: str, password: str):
        import requests
        self.session = requests.Session()
        self.username = username
        self.password = password
        self._authenticated = False

    def authenticate(self):
        """Login to Space-Track."""
        resp = self.session.post(self.LOGIN_URL, data={
            "identity": self.username,
            "password": self.password,
        })
        if resp.status_code != 200 or "Failed" in resp.text:
            raise RuntimeError(f"Authentication failed: {resp.text[:200]}")
        self._authenticated = True
        print("  Authenticated with Space-Track.org")

    def query(self, endpoint: str, params: dict = None, limit: int = None):
        """
        Query the Space-Track API.

        Args:
            endpoint: e.g., "basicspacedata/query/class/satcat"
            params: dict of query parameters (predicates)
            limit: max results

        Returns:
            list of dicts (JSON response)
        """
        if not self._authenticated:
            self.authenticate()

        # Build the request URL from predicates
        url = f"{self.BASE_URL}/{endpoint}"

        if params:
            for key, val in params.items():
                url += f"/{key}/{val}"

        if limit:
            url += f"/limit/{limit}"

        url += "/format/json"

        print(f"  Querying: ...{url[-80:]}")
        resp = self.session.get(url)

        if resp.status_code != 200:
            raise RuntimeError(f"Query failed ({resp.status_code}): {resp.text[:200]}")

        data = resp.json()
        print(f"  Received {len(data)} records")
        return data

    def get_satcat(self, current_only: bool = False):
        """
        Fetch the full satellite catalog.

        Returns list of dicts with keys like:
          NORAD_CAT_ID, OBJECT_TYPE, LAUNCH, DECAY, PERIOD, INCLINATION, APOGEE, PERIGEE, ...
        """
        params = {}
        if current_only:
            params["DECAY"] = "null-val"  # only objects still in orbit

        return self.query(
            "basicspacedata/query/class/satcat",
            params=params,
        )

    def get_current_gp(self):
        """
        Fetch current GP (orbital elements) for all tracked objects.

        Returns list of dicts with keys like:
          NORAD_CAT_ID, EPOCH, MEAN_MOTION, ECCENTRICITY, INCLINATION,
          SEMIMAJOR_AXIS, APOAPSIS, PERIAPSIS, OBJECT_TYPE, ...
        """
        return self.query(
            "basicspacedata/query/class/gp",
            params={"DECAY_DATE": "null-val"},  # still in orbit
        )

    def get_gp_history(self, norad_id: int, start_date: str, end_date: str):
        """
        Fetch GP history for a specific object.
        Use sparingly — this is expensive.
        """
        return self.query(
            "basicspacedata/query/class/gp_history",
            params={
                "NORAD_CAT_ID": str(norad_id),
                "EPOCH": f"{start_date}--{end_date}",
                "orderby": "EPOCH asc",
            },
            limit=500,
        )


# ═══════════════════════════════════════════════════════════════
# 2. Altitude Computation
# ═══════════════════════════════════════════════════════════════

R_EARTH_KM = 6371.0

def mean_motion_to_altitude(mean_motion_revs_per_day: float) -> float:
    """
    Convert mean motion (revolutions/day) to approximate altitude (km).

    Uses Kepler's third law:
      a = (GM / (2π·n)²)^(1/3)
      altitude = a - R_earth

    where GM_earth = 398600.4418 km³/s², n in rad/s.
    """
    if mean_motion_revs_per_day <= 0:
        return -1

    GM = 398600.4418  # km³/s²
    n_rad_s = mean_motion_revs_per_day * 2 * np.pi / 86400.0
    a = (GM / (n_rad_s ** 2)) ** (1.0 / 3.0)
    return a - R_EARTH_KM


def semimajor_to_altitude(sma_km: float) -> float:
    """Convert semi-major axis (km) to altitude (km)."""
    return sma_km - R_EARTH_KM


# ═══════════════════════════════════════════════════════════════
# 3. Data Processing
# ═══════════════════════════════════════════════════════════════

def classify_object(obj: dict) -> str:
    """
    Classify a SATCAT object as 'payload', 'debris', or 'rocket_body'.

    OBJECT_TYPE values in Space-Track SATCAT:
      PAYLOAD     = active/inactive satellite
      ROCKET BODY = spent upper stage
      DEBRIS      = fragmentation debris
      TBA         = to be assigned
      UNKNOWN     = unknown
    """
    otype = obj.get("OBJECT_TYPE", "").strip().upper()
    if "PAYLOAD" in otype or otype == "PAY":
        return "payload"
    elif "DEBRIS" in otype or otype == "DEB":
        return "debris"
    elif "ROCKET" in otype or otype in ("R/B", "RB"):
        return "rocket_body"
    else:
        return "unknown"


def parse_date(date_str: str) -> Optional[float]:
    """Parse Space-Track date string to fractional year."""
    if not date_str or date_str.strip() == "":
        return None
    try:
        # Try ISO format first
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        year = dt.year + (dt.timetuple().tm_yday - 1) / 365.25
        return year
    except (ValueError, TypeError):
        try:
            # Try just the date part
            dt = datetime.strptime(date_str[:10], "%Y-%m-%d")
            year = dt.year + (dt.timetuple().tm_yday - 1) / 365.25
            return year
        except (ValueError, TypeError):
            return None


def get_object_altitude(obj: dict) -> Optional[float]:
    """
    Get approximate altitude from SATCAT or GP record.

    Tries multiple fields in order of preference:
      1. SEMIMAJOR_AXIS (GP records)
      2. APOAPSIS/PERIAPSIS average (GP records)
      3. APOGEE/PERIGEE average (SATCAT records)
      4. MEAN_MOTION (GP records)
      5. PERIOD (SATCAT records)
    """
    # GP-style fields
    sma = obj.get("SEMIMAJOR_AXIS")
    if sma and float(sma) > 0:
        return semimajor_to_altitude(float(sma))

    apo = obj.get("APOAPSIS") or obj.get("APOGEE")
    peri = obj.get("PERIAPSIS") or obj.get("PERIGEE")
    if apo and peri:
        try:
            return (float(apo) + float(peri)) / 2.0
        except (ValueError, TypeError):
            pass

    mm = obj.get("MEAN_MOTION")
    if mm:
        try:
            return mean_motion_to_altitude(float(mm))
        except (ValueError, TypeError):
            pass

    period = obj.get("PERIOD")
    if period:
        try:
            # Period in minutes → mean motion in rev/day
            p_min = float(period)
            if p_min > 0:
                mm_rev_day = 1440.0 / p_min
                return mean_motion_to_altitude(mm_rev_day)
        except (ValueError, TypeError):
            pass

    return None


def process_satcat(satcat_data: list, alt_min: float, alt_max: float,
                   gp_data: list = None) -> dict:
    """
    Process SATCAT records into yearly time series filtered by altitude.

    Args:
        satcat_data: list of SATCAT records
        alt_min: minimum altitude (km)
        alt_max: maximum altitude (km)
        gp_data: optional current GP data for better altitude estimates

    Returns:
        dict with years, active_satellites, debris_count, launches, etc.
    """
    # Build altitude lookup from GP data (more accurate than SATCAT)
    alt_lookup = {}
    if gp_data:
        for obj in gp_data:
            norad_id = obj.get("NORAD_CAT_ID")
            if norad_id:
                alt = get_object_altitude(obj)
                if alt is not None:
                    alt_lookup[str(norad_id)] = alt

    # Process each SATCAT object
    # Track: when was it in orbit (launch → decay), what type, what altitude
    objects = []
    for obj in satcat_data:
        norad_id = str(obj.get("NORAD_CAT_ID", ""))
        otype = classify_object(obj)

        launch_year = parse_date(obj.get("LAUNCH", ""))
        decay_year = parse_date(obj.get("DECAY", ""))

        if launch_year is None:
            continue

        # Get altitude — prefer GP lookup, fall back to SATCAT fields
        alt = alt_lookup.get(norad_id) or get_object_altitude(obj)

        # If we can't determine altitude, skip (or use a heuristic)
        if alt is None:
            continue

        # Filter by altitude band
        if alt < alt_min or alt > alt_max:
            continue

        objects.append({
            "norad_id": norad_id,
            "type": otype,
            "launch_year": launch_year,
            "decay_year": decay_year,  # None if still in orbit
            "altitude": alt,
        })

    print(f"  {len(objects)} objects in {alt_min}-{alt_max} km shell")
    type_counts = defaultdict(int)
    for o in objects:
        type_counts[o["type"]] += 1
    for t, c in sorted(type_counts.items()):
        print(f"    {t}: {c}")

    # Bin into yearly time series
    if not objects:
        raise ValueError("No objects found in the specified altitude band")

    min_year = int(min(o["launch_year"] for o in objects))
    max_year = int(max(o["launch_year"] for o in objects)) + 1
    years = np.arange(min_year, max_year + 1, dtype=float)

    active = np.zeros(len(years))
    debris = np.zeros(len(years))
    rocket_bodies = np.zeros(len(years))
    launches_per_year = np.zeros(len(years))

    for obj in objects:
        launch_yr = obj["launch_year"]
        decay_yr = obj["decay_year"] or max_year + 10  # still in orbit

        for i, yr in enumerate(years):
            if launch_yr <= yr < decay_yr:
                if obj["type"] == "payload":
                    active[i] += 1
                elif obj["type"] == "debris":
                    debris[i] += 1
                elif obj["type"] == "rocket_body":
                    rocket_bodies[i] += 1

        # Count launches
        launch_idx = int(launch_yr) - min_year
        if 0 <= launch_idx < len(years):
            launches_per_year[launch_idx] += 1

    # Identify major fragmentation events (years with large debris jumps)
    d_debris = np.diff(debris)
    med = np.median(d_debris)
    mad = np.median(np.abs(d_debris - med)) * 1.4826

    frag_times = []
    frag_q2_before = []
    frag_produced = []

    for i in range(len(d_debris)):
        if d_debris[i] > med + 5 * mad and d_debris[i] > 50:
            frag_times.append(years[i + 1])
            frag_q2_before.append(debris[i])
            frag_produced.append(d_debris[i])

    return {
        "years": years,
        "active_satellites": active,
        "debris_count": debris,
        "rocket_bodies": rocket_bodies,
        "launches": launches_per_year,
        "frag_times": np.array(frag_times),
        "frag_q2_before": np.array(frag_q2_before),
        "frag_produced": np.array(frag_produced),
        "n_objects": len(objects),
    }


def save_csv(data: dict, filepath: str, shell_name: str = ""):
    """Save processed data to CSV for the EWS pipeline."""
    years = data["years"]
    n = len(years)

    with open(filepath, "w") as f:
        # Header
        f.write("year,active_satellites,debris_count,launches,"
                "rocket_bodies,frag_time,frag_q2_before,frag_produced\n")

        frag_set = {}
        for i in range(len(data.get("frag_times", []))):
            yr = data["frag_times"][i]
            frag_set[yr] = (data["frag_q2_before"][i], data["frag_produced"][i])

        for i in range(n):
            yr = years[i]
            frag = frag_set.get(yr, (0, 0))
            f.write(f"{yr:.1f},{data['active_satellites'][i]:.0f},"
                    f"{data['debris_count'][i]:.0f},"
                    f"{data['launches'][i]:.0f},"
                    f"{data['rocket_bodies'][i]:.0f},"
                    f"{frag[0]:.0f},{frag[0]:.0f},{frag[1]:.0f}\n")

    print(f"  Saved: {filepath}")
    print(f"  Years: {years[0]:.0f}-{years[-1]:.0f}")
    print(f"  Final active: {data['active_satellites'][-1]:.0f}")
    print(f"  Final debris: {data['debris_count'][-1]:.0f}")
    print(f"  Fragmentation events: {len(data.get('frag_times', []))}")


# ═══════════════════════════════════════════════════════════════
# 4. Offline Processing (from saved JSON)
# ═══════════════════════════════════════════════════════════════

def process_offline(satcat_path: str, alt_min: float, alt_max: float,
                    gp_path: str = None) -> dict:
    """Process previously downloaded SATCAT JSON."""
    print(f"  Loading SATCAT from {satcat_path}...")
    with open(satcat_path, "r") as f:
        satcat = json.load(f)
    print(f"  Loaded {len(satcat)} SATCAT records")

    gp = None
    if gp_path:
        print(f"  Loading GP from {gp_path}...")
        with open(gp_path, "r") as f:
            gp = json.load(f)
        print(f"  Loaded {len(gp)} GP records")

    return process_satcat(satcat, alt_min, alt_max, gp)


# ═══════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Fetch Space-Track data for debris EWS analysis"
    )
    parser.add_argument("--user", type=str, default=None,
                        help="Space-Track username (or set SPACETRACK_USER env)")
    parser.add_argument("--password", type=str, default=None,
                        help="Space-Track password (or set SPACETRACK_PASSWORD env)")
    parser.add_argument("--alt_min", type=float, default=500,
                        help="Altitude band lower bound (km)")
    parser.add_argument("--alt_max", type=float, default=600,
                        help="Altitude band upper bound (km)")
    parser.add_argument("--output", type=str, default="shell_data.csv",
                        help="Output CSV path")
    parser.add_argument("--offline", type=str, default=None,
                        help="Path to previously saved SATCAT JSON (skip API)")
    parser.add_argument("--gp_json", type=str, default=None,
                        help="Path to previously saved GP JSON (offline mode)")
    parser.add_argument("--save_raw", action="store_true",
                        help="Save raw SATCAT and GP JSON for later offline use")
    args = parser.parse_args()

    shell_name = f"{args.alt_min:.0f}-{args.alt_max:.0f}km"
    print(f"\n{'='*60}")
    print(f"  Space-Track Data Fetcher")
    print(f"  Shell: {shell_name}")
    print(f"{'='*60}")

    if args.offline:
        # Process from saved files
        data = process_offline(args.offline, args.alt_min, args.alt_max,
                               args.gp_json)
    else:
        # Fetch from API
        username = args.user or os.environ.get("SPACETRACK_USER")
        password = args.password or os.environ.get("SPACETRACK_PASSWORD")

        if not username or not password:
            print("\n  ERROR: Space-Track credentials required.")
            print("  Set SPACETRACK_USER and SPACETRACK_PASSWORD environment variables,")
            print("  or use --user and --password flags.")
            print("  Create a free account at: https://www.space-track.org/auth/createAccount")
            sys.exit(1)

        client = SpaceTrackClient(username, password)
        client.authenticate()

        # Fetch SATCAT
        print("\n  Fetching SATCAT (full catalog)...")
        satcat = client.get_satcat()
        time.sleep(2)  # rate limit

        # Fetch current GP
        print("  Fetching current GP (orbital elements)...")
        gp = client.get_current_gp()

        # Optionally save raw data
        if args.save_raw:
            raw_dir = "raw_data"
            os.makedirs(raw_dir, exist_ok=True)
            with open(f"{raw_dir}/satcat.json", "w") as f:
                json.dump(satcat, f)
            with open(f"{raw_dir}/gp.json", "w") as f:
                json.dump(gp, f)
            print(f"  Raw data saved to {raw_dir}/")

        # Process
        print(f"\n  Processing for {shell_name} shell...")
        data = process_satcat(satcat, args.alt_min, args.alt_max, gp)

    # Save CSV
    save_csv(data, args.output, shell_name)

    # Quick summary plot
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(2, 2, figsize=(12, 8))

        ax = axes[0, 0]
        ax.plot(data['years'], data['active_satellites'], 'b-', lw=2)
        ax.set_title(f'Active satellites ({shell_name})')
        ax.set_xlabel('Year')
        ax.grid(True)

        ax = axes[0, 1]
        ax.plot(data['years'], data['debris_count'], 'r-', lw=2)
        ax.set_title(f'Tracked debris ({shell_name})')
        ax.set_xlabel('Year')
        ax.grid(True)

        ax = axes[1, 0]
        ax.bar(data['years'], data['launches'], color='green', alpha=0.7)
        ax.set_title('Launches per year')
        ax.set_xlabel('Year')
        ax.grid(True)

        ax = axes[1, 1]
        total = data['active_satellites'] + data['debris_count'] + data['rocket_bodies']
        ax.stackplot(data['years'],
                     data['active_satellites'],
                     data['debris_count'],
                     data['rocket_bodies'],
                     labels=['Payloads', 'Debris', 'Rocket bodies'],
                     alpha=0.7)
        ax.legend(loc='upper left', fontsize=9)
        ax.set_title(f'Total objects ({shell_name})')
        ax.set_xlabel('Year')
        ax.grid(True)

        fig.suptitle(f'Space-Track Data: {shell_name} shell', fontsize=14)
        fig.tight_layout()
        plot_path = args.output.replace('.csv', '_summary.png')
        fig.savefig(plot_path, dpi=150)
        print(f"  Summary plot: {plot_path}")
        plt.close()
    except ImportError:
        pass

    print(f"\n  Done. Run the EWS pipeline:")
    print(f"  python real_data_pipeline.py --csv {args.output} --Tw 10 --baseline 1990")


if __name__ == "__main__":
    main()
